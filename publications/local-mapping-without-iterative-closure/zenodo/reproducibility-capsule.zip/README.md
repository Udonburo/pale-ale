# Reproducibility capsule

This capsule accompanies:

> **Local Mapping Without Iterative Closure: Zero-Shot and
> Input-Output-Only In-Context Graph-XOR Capability Boundaries in Qwen3**

Author: Aoi Kawasaki  
DOI: 10.5281/zenodo.21992852  
Status: DOI-bearing technical-report capsule  
Date: 18 August 2026

## What this capsule supports

The capsule makes the frozen plans, public-safe runners, cell-level summary
metrics, capability matrix source data, model/runtime revisions, and SHA-256
bindings available for audit. It does not include model weights, provider
credentials, private paths, caches, signed URLs, account identifiers, or
activation tensors.

The strongest supported claim is:

> Correct input-output demonstrations made a two-input XOR mapping
> behaviorally available in Qwen3-4B and Qwen3-8B, but no
> correct-demonstration P3 cell met the predeclared score-signal criterion on
> the frozen ledgers at 4, 16, or 64 demonstrations.

Correct-demonstration P2 cells passed behaviorally at 16 and 64 shots in 4B
and at 4, 16, and 64 shots in 8B. Under the joint correct-versus-shuffled
formation rule, the earliest qualifying shot count was 16 for 4B and 4 for
8B; the corresponding 16- and 64-shot correct-versus-shuffled contrasts in
8B did not satisfy the joint formation criterion.

In the ICL branches, P5 remained unopened by conditional stopping. In the
zero-shot scout, P4 and P5 were measured and showed no detected signal.
A2-M, decorated-theta B, activation extraction, naturality, and causal
intervention remained unopened across every branch.

Each ICL branch used one prospectively fixed demonstration bank and order;
bank-to-bank and order-to-order variance were not assessed.

## Inventory

```text
README.md
LICENSES.txt
report-source.tex
capability-matrix-publication.png
plans/
  R1_v1_0_PUBLIC_SPEC_EXCERPT.md
  R1_1_CAPABILITY_LOCALIZATION.md
  R1_2_ICL_FORMATION.md
  R1_2_8B_FORMATION_BOUNDARY.md
code/
  LICENSE-MPL-2.0.txt
  make_capability_matrix.py
  run_r1_1.py
  run_r1_2.py
  run_r1_2_8b.py
results/
  branch_summary.json
  capability_matrix.json
  icl_cells.csv
bindings/
  runtime-and-models.json
  SHA256SUMS.txt
```

## Rebuild the public matrix

From the capsule root, with Python 3 and Matplotlib available:

```bash
python code/make_capability_matrix.py \
  --input results/capability_matrix.json \
  --output capability-matrix-publication.png
```

The model runners are preserved as public-name-neutralized audit copies. They
require the pinned model snapshots and the original execution environment;
they are not designed to download weights implicitly. Historical hashes of
the executed local artifacts remain in `bindings/runtime-and-models.json`,
while `bindings/SHA256SUMS.txt` binds the name-neutralized public copies. This
editorial export transformation does not change the frozen result summaries.
The report result does not require rerunning closed model campaigns to inspect
the frozen metrics.

## Integrity

`bindings/SHA256SUMS.txt` binds every file in this capsule except the checksum
file itself. The top-level Zenodo package has a separate checksum inventory.

## Scope boundary

This capsule does not establish a reusable XOR algorithm, a hidden iterative
state, a global-obstruction representation, or absence of hidden information.
It closes only the tested Qwen3 zero-shot and bounded input-output-only ICL
graph-XOR route.
