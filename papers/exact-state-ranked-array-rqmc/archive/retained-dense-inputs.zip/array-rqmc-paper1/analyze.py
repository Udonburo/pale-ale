"""Rebuild all Paper I numerical tables and figures from saved observations."""
from collections import defaultdict
from fractions import Fraction
import base64
import csv
import gzip
import json
from pathlib import Path
import statistics as st
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
METHODS = ('counting','prefix','boundary')
COLORS = dict(counting='#535b66', prefix='#176a8a', boundary='#cf7132')
LABELS = dict(counting='Explicit counting', prefix='Cached prefix', boundary='Boundary')


def table(path, caption, headings, rows):
    lines = [caption, '', '| '+' | '.join(headings)+' |',
             '| '+' | '.join(['---']*len(headings))+' |']
    lines += ['| '+' | '.join(str(v) for v in row)+' |' for row in rows]
    path.write_text('\n'.join(lines)+'\n',encoding='utf-8')


def ci_median(a, rng):
    a = np.asarray(a)
    boot = np.median(a[rng.integers(0,len(a),(4000,len(a)))],axis=1)
    return [float(v) for v in np.quantile(boot,[.025,.975])]


def main():
    data = ROOT/'data/confirmation'
    done = json.loads((data/'completion.json').read_text())
    manifest = json.loads((data/'manifest.json').read_text())
    assert done['returned']==manifest['count']==39 and done['errors']==0
    rows, memory, jobs = [], [], []
    expected = {json.dumps(s,sort_keys=True) for s in manifest['conditions']}
    seen = set()
    checks = endpoint_hits = 0
    representatives = 0
    for path in sorted(data.glob('job_*.json')):
        job = json.loads(path.read_text())
        assert job['status']=='ok'
        spec = job['spec']
        key = json.dumps(spec,sort_keys=True)
        assert key in expected and key not in seen
        seen.add(key)
        jobs.append(job)
        if spec['kind']=='memory':
            memory.extend(job['memory_rows'])
            continue
        checks += job['matched_step_histograms']
        hist = json.loads(gzip.decompress(base64.b64decode(job['representative_histograms_gzip_base64'])))
        assert len(hist)==spec['horizon']
        for step in hist:
            assert sum(n for _,n in step)==1<<spec['m']
            assert all(n>0 for _,n in step)
            assert [x for x,_ in step]==sorted(set(x for x,_ in step))
        representatives += len(hist)
        groups = defaultdict(list)
        for row in job['rows']:
            row = dict(kind=spec['kind'],model=spec['name'],m=spec['m'],T=spec['horizon'],
                       batch=spec['batch'],job=path.stem,**row)
            assert len(row['traces'])==len(row['diagnostics'])==row['T']
            assert float(row['seconds'])>0
            # Reported readouts are exact sums of the retained integer traces.
            a = (sum(t[0] for t in row['traces']) if row['kind']=='tandem'
                 else row['traces'][-1][0])
            assert a==row['numerator']
            assert Fraction(a,row['denominator'])==Fraction(row['value'])
            if row['kind']=='tandem':
                assert sum(t[1] for t in row['traces'])==row['alternate_numerator']
                assert Fraction(row['alternate_numerator'],row['denominator'])==Fraction(row['alternate_value'])
            groups[row['seed']].append(row)
            rows.append(row)
        for paired in groups.values():
            assert {r['method'] for r in paired}==set(METHODS)
            assert all(r['traces']==paired[0]['traces'] for r in paired)
            assert len({r['value'] for r in paired})==1
            assert len({r['alternate_value'] for r in paired})==1
            endpoint_hits += sum(d['endpoint_hits'] for d in paired[0]['diagnostics'])
    assert seen==expected and len(rows)==1242 and len(memory)==27 and checks==154560
    totals = defaultdict(dict)
    cells = defaultdict(list)
    for r in rows:
        totals[(r['model'],r['m'],r['seed'])][r['method']]=r
        cells[(r['model'],r['m'],r['method'])].append(r)
    rng = np.random.default_rng(410001)
    comparisons = []
    for model,m in sorted(set(k[:2] for k in cells)):
        pairs = [p for (name,bits,_),p in sorted(totals.items()) if (name,bits)==(model,m)]
        n = len(pairs)
        assert n==(128 if model=='tandem' else 5)
        comp = dict(model=model,m=m,n=n,methods={},ratios={})
        for method in METHODS:
            times = [p[method]['seconds'] for p in pairs]
            comp['methods'][method] = dict(median=float(np.median(times)),
                min=min(times),max=max(times),total=sum(times),
                phases={phase:float(np.median([p[method]['phases'][phase] for p in pairs]))
                        for phase in pairs[0][method]['phases']})
        for method in ('prefix','boundary'):
            ratios = [p['counting']['seconds']/p[method]['seconds'] for p in pairs]
            comp['ratios'][method] = dict(median=float(np.median(ratios)),min=min(ratios),max=max(ratios))
            if n==128:
                comp['ratios'][method]['bootstrap95']=ci_median(ratios,rng)
        rpb = [p['prefix']['seconds']/p['boundary']['seconds'] for p in pairs]
        comp['prefix_over_boundary'] = float(np.median(rpb))
        comp['diagnostics'] = dict(
            maxS=max(d['S_next'] for p in pairs for d in p['boundary']['diagnostics']),
            maxMixed=max(d['mixed'] for p in pairs for d in p['boundary']['diagnostics']),
            meanResidual=float(np.mean([d['residual_slots'] for p in pairs for d in p['boundary']['diagnostics']])),
            meanPrefixAdditions=float(np.mean([d['prefix_additions'] for p in pairs for d in p['prefix']['diagnostics']])),
            endpointHits=sum(d['endpoint_hits'] for p in pairs for d in p['boundary']['diagnostics']))
        comparisons.append(comp)
    old = json.loads((ROOT/'supporting/summary.json').read_text())
    truth = next(r for r in old['exact_tandem'] if r['finite_word'])
    errors = []
    samples = {}
    for m in (12,16,20):
        rs = sorted(cells[('tandem',m,'boundary')], key=lambda r:r['seed'])
        for field,dpname in [('value','mean'),('alternate_value','rare')]:
            exact_errors = [Fraction(r[field])-Fraction(truth[dpname]) for r in rs]
            e = np.array([float(v) for v in exact_errors])
            samples[(m,dpname)] = e
            errors.append(dict(m=m,readout=dpname,n=len(e),truth=float(Fraction(truth[dpname])),
                sample_mean_error=float(e.mean()),sample_variance=float(e.var(ddof=1)),
                rmse=float(np.sqrt(np.mean(e**2))),q025=float(np.quantile(e,.025)),
                q5=float(np.median(e)),q975=float(np.quantile(e,.975))))
    follow = ROOT/'data/memory_sampled'
    memdone = json.loads((follow/'completion.json').read_text())
    assert memdone['returned']==9 and memdone['errors']==0
    memjobs = [json.loads(p.read_text()) for p in sorted(follow.glob('job_*.json'))]
    memgroups = defaultdict(list)
    for r in [r for j in memjobs for r in j['rows']]:
        key = (r['request']['spec']['m'],r['request']['method'])
        memgroups[key].append(r)
    memsummary = []
    for (m,method),rs in sorted(memgroups.items()):
        assert len(rs)==3
        memsummary.append(dict(m=m,method=method,n=3,
            measurement='Sampled RSS lower bound, not OS continuous-time peak',
            warmed_mib=st.median(r['ready']['rss'] for r in rs)/2**20,
            total_peak_mib=st.median(r['sampled_peak_bytes'] for r in rs)/2**20,
            peak_increment_mib=st.median(max(0,r['sampled_peak_bytes']-r['ready']['rss']) for r in rs)/2**20,
            peak_increment_min_mib=min(max(0,r['sampled_peak_bytes']-r['ready']['rss']) for r in rs)/2**20,
            peak_increment_max_mib=max(max(0,r['sampled_peak_bytes']-r['ready']['rss']) for r in rs)/2**20,
            maximum_sampling_gap=max(r['maximum_sampling_gap'] for r in rs),
            samples=sum(len(r['samples']) for r in rs),
            table_bytes=rs[0]['result']['table_bytes']))
    # The replacement measurement reruns only memory, with the original seeds.
    oldmemory={(r['request']['spec']['m'],r['request']['method'],r['request']['seed']):r for r in memory}
    for j in memjobs:
        assert j['status']=='ok'
        for r in j['rows']:
            key=(r['request']['spec']['m'],r['request']['method'],r['request']['seed'])
            assert r['result']['value']==oldmemory[key]['value']
            assert r['result']['alternate_value']==oldmemory[key]['alternate_value']
    (ROOT/'tables').mkdir(exist_ok=True)
    (ROOT/'figures').mkdir(exist_ok=True)
    out = dict(status='PASS',rows=len(rows),matched_step_histograms=checks,
               stored_representative_checkpoints=representatives,comparisons=comparisons,
               error_summaries=errors,memory=memsummary,endpoint_hits=endpoint_hits,
               original_memory_hwm_available=sum('VmHWM' in r['after'] for r in memory),
               memory_followup_jobs=len(memjobs),
               cpu_names=sorted(set(j['cpu'] for j in jobs)),
               function_wall_seconds=sum(j['wall_seconds'] for j in jobs+memjobs),
               base_resource_estimate_usd=sum(j['wall_seconds'] for j in jobs+memjobs)*(.0000131+2*.00000222),
               billing_note='Requested-resource runtime estimate, not invoice; excludes build/startup/idle.',
               bootstrap_note='Paired 4000-resample percentile intervals; host/batch uncertainty remains.',
               exact_truth_source='supporting/summary.json')
    (ROOT/'summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    with (ROOT/'timings.csv').open('w',newline='',encoding='utf-8') as f:
        cols=['model','m','T','seed','batch','job','method','seconds','value','alternate_value']
        writer=csv.DictWriter(f,fieldnames=cols,extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    finite = [c for c in comparisons if c['model']!='tandem']
    tandem = [c for c in comparisons if c['model']=='tandem']
    table(ROOT/'tables/finite.md',
          '**Table 2. Finite-model ablation.** Median milliseconds per 16-step realization; five paired seeds per cell. Ratios are medians of paired explicit/implicit times.',
          ['Model','$m$','Explicit','Prefix','Boundary','E/P','E/B'],
          [[c['model'],c['m'],*[f"{c['methods'][v]['median']*1000:.2f}" for v in METHODS],
            *[f"{c['ratios'][v]['median']:.2f}" for v in ('prefix','boundary')]] for c in finite])
    table(ROOT/'tables/tandem.md',
          '**Table 3. Published tandem model.** Median seconds per 200-step realization and paired speedups, with 95% paired-bootstrap intervals; 128 independent randomizations at each population size.',
          ['$m$','Explicit','Prefix','Boundary','E/P [interval]','E/B [interval]'],
          [[c['m'],*[f"{c['methods'][v]['median']:.3f}" for v in METHODS],
            *[f"{c['ratios'][v]['median']:.2f} [{c['ratios'][v]['bootstrap95'][0]:.2f}, {c['ratios'][v]['bootstrap95'][1]:.2f}]"
              for v in ('prefix','boundary')]] for c in tandem])
    table(ROOT/'tables/errors.md',
          '**Table 4. The same finite-sample error observations from all three executors.** Errors are measured against the exact finite-word one-chain mean. Quantiles summarize these 128 realizations, rather than asserting population tail coverage.',
          ['$m$','Readout','Mean error','Sample variance','RMSE','2.5% / 97.5% error'],
          [[e['m'],'Length' if e['readout']=='mean' else 'Exceedance',
            f"{e['sample_mean_error']:.3e}",f"{e['sample_variance']:.3e}",f"{e['rmse']:.3e}",
            f"{e['q025']:.3e} / {e['q975']:.3e}"] for e in errors])
    table(ROOT/'tables/memory.md',
          '**Table E1. Fresh-process sampled RSS, in MiB.** Medians of three trajectories after a common small JIT warmup. A parent polls RSS at a requested 2 ms interval. Sampled maxima lower-bound continuous-time peaks; increments are not exact allocation counts.',
          ['$m$','Method','Warmed RSS','Sampled peak','Increment','Common tables'],
          [[r['m'],LABELS[r['method']],f"{r['warmed_mib']:.1f}",f"{r['total_peak_mib']:.1f}",
            f"{r['peak_increment_mib']:.1f}",f"{r['table_bytes']/2**20:.3f}"] for r in memsummary])
    table(ROOT/'tables/diagnostics.md',
          '**Table B1. Work descriptors for the tandem model.** Maxima range across all 128 trajectories; residual slots and prefix vector additions are means per step. Each suffix-image symbol addition is counted once.',
          ['$m$','Max states','Max mixed blocks','Residual slots/step','Prefix additions/step','Endpoint hits'],
          [[c['m'],c['diagnostics']['maxS'],c['diagnostics']['maxMixed'],
            f"{c['diagnostics']['meanResidual']:.1f}",f"{c['diagnostics']['meanPrefixAdditions']:.1f}",
            c['diagnostics']['endpointHits']] for c in tandem])
    previous_rows = defaultdict(list)
    for path in sorted((ROOT/'supporting/data/cloud').glob('job_*.json')):
        job = json.loads(path.read_text())
        assert job['status']=='ok'
        if job['spec']['suite']=='baseline' and job['spec']['m']==20:
            for row in job['rows']:
                previous_rows[(job['spec']['name'],row['method'])].append(row['seconds'])
    assert len(previous_rows)==15 and all(len(v)==5 for v in previous_rows.values())
    previous = {k:st.median(v)*1000 for k,v in previous_rows.items()}
    saved_previous = {(r['model'],r['method']):r['median_seconds']*1000 for r in old['aggregates']
                      if r['platform']=='cloud' and r['suite']=='baseline' and r['m']==20}
    assert previous==saved_previous
    table(ROOT/'tables/previous.md',
          '**Table C1. Preceding baseline-selection study.** Median milliseconds for 16 steps at $N=2^{20}$, five paired seeds. These observations predate the present confirmation and are not pooled with Table 2.',
          ['Model','Full points','Affine + sort','Finite-B order','Counting','Boundary'],
          [[name,*[f"{previous[(name,method)]:.2f}" for method in
                    ('full_points','affine_sort','finite_b_order','counting_explicit','compressed')]]
           for name in ('queue16','queue64','inventory32')])
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.hashsalt':'array-rqmc-paper1', 'axes.spines.top':False,
                         'axes.spines.right':False,'savefig.bbox':'tight'})
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.6),layout='constrained')
    for method in METHODS:
        med=[c['methods'][method]['median'] for c in tandem]
        axes[0].plot([12,16,20],med,'o-',color=COLORS[method],label=LABELS[method])
    axes[0].set(yscale='log',xlabel=r'Population exponent $m$ ($N=2^m$)',ylabel='Seconds per realization',
                xticks=[12,16,20],title='(A) Retained implementations')
    axes[0].legend(fontsize=8,frameon=False)
    phases=['setup','input','counts','update','readout']
    phasecolors=['#c6c8cc','#476e94','#29a6a0','#ce853e','#826b98']
    c=tandem[-1]
    bottoms=np.zeros(3)
    for phase,color in zip(phases,phasecolors):
        vals=np.array([c['methods'][v]['phases'][phase] for v in METHODS])
        axes[1].bar(range(3),vals,bottom=bottoms,color=color,label=phase)
        bottoms+=vals
    axes[1].set(xticks=range(3),xticklabels=['Explicit','Prefix','Boundary'],
                ylabel='Component median seconds',title=r'(B) Components at $N=2^{20}$')
    axes[1].legend(fontsize=7,ncol=2,frameon=False)
    fig.savefig(ROOT/'figures/costs.svg',metadata={'Date':None})
    fig.savefig(ROOT/'figures/costs.png',dpi=600)
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.5),layout='constrained')
    for ax,dpname,title in zip(axes,['mean','rare'],['(A) Time-averaged length','(B) Queue 2 exceedance']):
        for m,color in zip((12,16,20),('#8c9eae','#277996','#cb7333')):
            e=np.sort(samples[(m,dpname)])
            ax.ecdf(e,color=color,label=rf'$2^{{{m}}}$')
        ax.axvline(0,color='#aaa',lw=.6)
        ax.set(xlabel='Estimator error',ylabel='Empirical CDF',title=title,ylim=(0,1))
        ax.ticklabel_format(axis='x',style='sci',scilimits=(-2,2))
        ax.legend(title='Population',frameon=False,fontsize=8,title_fontsize=8)
    fig.savefig(ROOT/'figures/errors.svg',metadata={'Date':None})
    fig.savefig(ROOT/'figures/errors.png',dpi=600)
    plt.close(fig)
    print(json.dumps({k:v for k,v in out.items() if k not in ['error_summaries']},indent=2))


if __name__=='__main__':
    main()
