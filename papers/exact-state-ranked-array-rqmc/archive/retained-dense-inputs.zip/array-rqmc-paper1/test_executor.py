"""Independent exact validation, separate from performance seeds."""
from collections import Counter
from itertools import product
import json
import random
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent
# Validate the exact uploaded implementation, including from an extracted package.
sys.path.insert(0, str(ROOT/'data/confirmation/source/array_rqmc_paper1'))
from executor import CachedPrefix, trajectory, old, symbol, warmup


def run():
    rng = random.Random(119771)
    checks = flows = 0
    for m in range(1,7):
        for d in (1,2,3):
            for _ in range(8):
                N, B = 1 << m, 1 << d
                cols = tuple(rng.randrange(B) for _ in range(m))
                b = rng.randrange(B)
                cached = CachedPrefix(cols, b, d)
                for stop in range(N+1):
                    direct = Counter(symbol(cols, r, b) for r in range(stop))
                    expected = [direct[z] for z in range(B)]
                    assert cached.prefix(stop) == expected
                    checks += 1
                cuts = [0]+sorted(rng.sample(range(1,N), min(N-1,4)))+[N]
                counts = [v-u for u,v in zip(cuts,cuts[1:])]
                result = cached.flows(counts)
                for row, lo, hi in zip(result,cuts,cuts[1:]):
                    direct = Counter(symbol(cols,r,b) for r in range(lo,hi))
                    assert row == [direct[z] for z in range(B)]
                flows += 1
    warmup()
    comparisons = 0
    inputs = [dict(model, m=8, horizon=7) for model in old.MODELS]
    inputs.append(dict(name='tandem', m=8, horizon=12))
    for spec in inputs:
        records = [trajectory(spec, 881117, method) for method in ('counting','prefix','boundary')]
        for rec in records[1:]:
            assert rec['histories'] == records[0]['histories']
            assert rec['traces'] == records[0]['traces']
            assert (rec['value'],rec['alternate_value']) == (records[0]['value'],records[0]['alternate_value'])
            comparisons += spec['horizon']
        prior = (old.tandem_trajectory(spec,881117,'compressed') if spec['name']=='tandem'
                 else old.baseline_trajectory(spec,881117,'compressed'))
        assert records[0]['histories'] == prior['histories']
        assert records[0]['value'] == prior['value']
    # Rank insufficiency is a failure of the contract, not a rounding error.
    before = [(0,1),(1,0)]
    assert Counter(before[0]) == Counter(before[1])
    after = [sorted(x+z for x,z in zip(xs,(0,1))) for xs in before]
    assert after == [[0,2],[1,1]]
    # Full-state ordering closes, including arbitrary duplicate labels.
    for xs in product(range(3),repeat=4):
        expected = sorted(x+z for x,z in zip(sorted(xs),(0,1,1,0)))
        for ys in (xs, tuple(reversed(xs))):
            assert sorted(x+z for x,z in zip(sorted(ys),(0,1,1,0))) == expected
    return dict(status='PASS', prefix_comparisons=checks, interval_partitions=flows,
                method_step_histograms=comparisons, rank_tie_counterexample=after,
                full_state_sort_conditions=81)


if __name__=='__main__':
    result = run()
    target = Path(__file__).with_name('validation.json')
    target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
