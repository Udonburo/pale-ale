"""Replay representative trajectories from the exact uploaded source copy."""
import base64
import gzip
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
data=ROOT/'data/confirmation'
sys.path.insert(0,str(data/'source/array_rqmc_paper1'))
import executor


def main():
    executor.warmup()
    checked=[]
    jobs=[json.loads(p.read_text()) for p in sorted(data.glob('job_*.json'))]
    selected=[j for j in jobs if j['spec'].get('kind')=='tandem' and j['spec']['batch']==0]
    selected += [j for j in jobs if j['spec'].get('kind')=='finite' and j['spec']['m']==10]
    for job in selected:
        spec=job['spec']
        reference=json.loads(gzip.decompress(base64.b64decode(job['representative_histograms_gzip_base64'])))
        for method in executor.METHODS:
            result=executor.trajectory(spec,spec['seed'],method)
            assert json.loads(json.dumps(result['histories']))==reference
            row=next(r for r in job['rows'] if r['method']==method and r['rep']==0)
            assert result['value']==row['value']
            assert result['alternate_value']==row['alternate_value']
            assert json.loads(json.dumps(result['traces']))==row['traces']
            checked.append(dict(model=spec['name'],m=spec['m'],seed=spec['seed'],
                                method=method,checkpoints=spec['horizon']))
    report=dict(status='PASS',source='data/confirmation/source',replays=checked,
                checkpoints=sum(r['checkpoints'] for r in checked))
    (ROOT/'saved_source_replay.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(dict(status=report['status'],trajectories=len(checked),checkpoints=report['checkpoints'])))


if __name__=='__main__':
    main()
