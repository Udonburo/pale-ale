# Paper I evidence completion

1 October 2026. Private successor study. Previous published manuscripts and
completed generalization, population and evidence runs retain their identities.
The present target is exact execution, not adaptive coupling design.

## Fixed questions

1. How much of the cost reduction comes from implicit prefix counting, and how
   much additionally comes from balanced interiors and explicit boundary slots?
2. What memory is actually required, including model tables and the runtime?
3. Can the published tandem queue's finite-N estimator error experiment be
   executed more cheaply while preserving every estimator realization?

All models and scientific parameters are already observed development choices.
The seeds below are fresh, not a claim of blinded model selection. Validation
uses separate seeds and small sizes. This protocol is written before these
new performance runs. No high-dimensional family, controller or new variance
optimization problem is part of this study.

## Methods and contracts

Three methods use the SAME realised SciPy 1.15.3 30-bit LMS+shift map, with fresh
independent randomization at every step. `counting` imports the previous Numba
integer counting-sort implementation unchanged. `prefix` builds and caches all
suffix images once per input map and reuses each interval endpoint count;
it does not repeatedly recompute suffix spans. `boundary` imports the prior
balanced-interior/residual implementation unchanged, including its generic
fallback. All three use the same model tables, map extraction, endpoint
corrections and integer readouts. Numba compilation is excluded after identical
small warmup. Model/map construction, updates, ordering and readout are included.
Equality audits and diagnostic counters are excluded from timing for all methods.

The contract is the complete histogram at every step and the supported exact
integer readout traces. Labels, original reduction order and arbitrary hidden
particle histories are not retained. Each model's declared sort distinguishes
its full transition state. A separate test demonstrates failure with an
insufficient tied sort key.

## Experiments

### A. Explanation of the previous speedups

Repeat queue16, queue64 and inventory32 at m=10,20, horizon16, five paired
seeds per cell, using the prior definitions without changes. Seeds are
2100000 + 10000*model_index + 100*m + replicate. The primary comparison is
counting / cached-prefix / boundary, not the weak original point-sort baseline.

### B. Published-model finite-sample error experiment

Use the already reproduced L'Ecuyer--Lecot--Tuffin (2008) Section4.4 tandem queue:
lambda=1, mu1=1.75, mu2=1.25, initially empty, 200 uniformized transitions;
sort by total queue length and then queue2. N=2^12,2^16,2^20. At each N, run
128 independent seeds, 3100000 + 10000*m + replicate, with all three methods.
Randomize method execution order within each seed. Partition seeds into eight
batches of16 for execution; the batch is not an extra statistical replicate.

Readouts are post-transition total queue length and indicator(queue2>4), averaged
over all200 steps and allN particles. Preserve the <= endpoint convention and
its two exact 30-bit affine-preimage corrections. DP for the actual finite-word
kernel supplies the true means; also report the continuous-uniform means as
distinct reference quantities. The old exact rational DP results are reused.

For each readout report sample variance, RMSE about the actual finite-word mean,
central empirical error quantiles and mean error. These describe the reference
estimator's finite-N behavior; no new variance-reduction claim is made.
Use paired equality and actual batch wall times to explain the cost of obtaining
these SAME observations. Do not infer1000 observed replications from a single
runtime or stop sampling at a wall-clock deadline. R=128 is inadequate for
precise extreme-tail or confidence-interval coverage claims. No power-law
convergence rate is fitted to only three sample sizes.

Time-ratio uncertainty is by paired bootstrap within N, fixed seed410001,
4000 resamples; report that host/batch effects remain. Summaries retain the
raw paired rows and timing losses. A common set of exact outcomes ensures
that the variance/quantile statistics are the same for each executor.

### C. Memory scaling

For each tandem N and method, measure three independent fresh subprocesses,
seeds5100000+10000*m+replicate. A process imports dependencies and performs only
the common small JIT warmup, then measures one200-step production trajectory
without retained validation histories. Record resident bytes just before the
trajectory, operating-system peak RSS before/after, and, if supported, Linux
VmHWM reset to the current value before execution. Keep total process peak
separate from the increment over the warmed runtime. Do not call either an
exact count of algorithm-owned bytes. Record compact-state and explicit-array
payload scales separately, including the common transition table.

One method/replicate per subprocess prevents cross-method allocator history
from contaminating peak measurements. Memory instrumentation runs are separate
from the primary time comparisons. A large fixed Python/JIT footprint may hide
an asymptotic storage benefit at the tested N; retain that outcome.

## Execution, validation and data

Small exhaustive prefix-count and rank-sufficiency tests run locally first.
The 24 tandem batches and six finite-model cells use one CPU and2GiB per
Modal task, max4 concurrent containers, no automatic retries,1500-second task
timeout. Nine memory tasks (one N/method, three subprocesses) have the same
limits. The specified total is39 tasks (24+6+9), with the
source driver deriving its manifest directly from these specifications.
At the previously checked base rates this all-timeout execution envelope is
39*1500*(0.0000131+2*0.00000222) = USD1.02609; image/startup/idle are additional,
so this is not an invoice or a billing cap. No GPU or persistent service.

Only the explicitly named executor modules are uploaded. Save that source,
specifications, versions, raw outcomes, returned errors and the representative
complete histogram trace for the first seed of each batch. Every seed's full
histograms are compared in the worker; retain all integer readout traces and
diagnostics. A mismatch returns its complete counterexample rather than being
discarded. Current runs are not pooled with prior timings. A failed write of
an already computed record can be retried without rerunning its experiment.

## Manuscript boundaries

The main theorem states a sufficient condition for reconstructing rank intervals
and commuting explicit execution with exact aggregation. Counts rely on known
finite-field linear algebra; the algorithmic object is the evolving, state-ranked
empirical process. Include input ingestion, map construction, destination
sorting and integer bit complexity. Profile data will not justify a universal
speedup or N-independent runtime. Controller success is not a publication gate.
The manuscript is private; no release, submission or external message is made.

## Memory follow-up after the original measurement

All39 tasks completed. The sandbox omits VmHWM and rejects clear_refs; retain
those27 records as a failed high-water measurement, not a production peak.
A separate nine-task memory follow-up uses the same N/method/three seeds and
fresh subprocesses, with a parent polling the child's VmRSS every2ms after a
small-warmup handshake. Keep the time-stamped samples. The maximum is an
**observed sampled RSS peak**, a lower bound on the true continuous-time peak;
report it as such. It is not used for the timing tables. No algorithm, seed,
parameter or primary time measurement is changed. Nine1CPU/2GiB tasks, max4
concurrent, timeout300seconds, no retries; base all-timeout envelope USD0.047358,
excluding build/startup/idle. This paragraph precedes the follow-up.
