"""Bounded follow-up to unavailable production VmHWM, without re-timing."""
from pathlib import Path
import json
import shutil
import sys
import time
import modal
HERE=Path(__file__).resolve().parent
LOCAL=HERE.parent
FILES=['array_rqmc_paper1/executor.py','array_rqmc_paper1/memory_sample.py',
       'array_rqmc_boundary/evidence/compare.py','array_rqmc_population/population.py',
       'array_rqmc_population/benchmarks.py','array_rqmc_generalization/generalized.py']
app=modal.App('array-rqmc-paper1-memory')
image=modal.Image.debian_slim(python_version='3.11').pip_install('numpy==1.26.4','scipy==1.15.3','numba==0.61.2')
for name in FILES:
    image=image.add_local_file(LOCAL/name,'/root/local/'+name)


@app.function(image=image,cpu=(1,1),memory=2048,timeout=300,retries=0,max_containers=4,scaledown_window=2)
def measure(spec):
    sys.path.insert(0,'/root/local/array_rqmc_paper1')
    from memory_sample import parent
    begin=time.perf_counter()
    rows=[]
    for rep in range(3):
        request=dict(spec=dict(name='tandem',m=spec['m'],horizon=200),
                     method=spec['method'],seed=5100000+10000*spec['m']+rep)
        rows.append(parent(request))
    return dict(status='ok',spec=spec,rows=rows,wall_seconds=time.perf_counter()-begin)


@app.local_entrypoint()
def main():
    out=HERE/'data/memory_sampled'
    if out.exists():
        raise FileExistsError('Preserve prior follow-up observations')
    out.mkdir(parents=True)
    for name in FILES:
        dst=out/'source'/name
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(LOCAL/name,dst)
    for name in ['modal_memory.py','PROTOCOL.md']:
        shutil.copyfile(HERE/name,out/'source'/name)
    conditions=[dict(m=m,method=method) for m in (12,16,20)
                for method in ('counting','prefix','boundary')]
    (out/'manifest.json').write_text(json.dumps(dict(conditions=conditions,timeout=300,retries=0,
        cpu=1,memory_mib=2048,max_containers=4,started_unix=time.time()),indent=2))
    returned=errors=0
    for result in measure.map(conditions,order_outputs=False,return_exceptions=True):
        if isinstance(result,BaseException):
            result=dict(status='failed',error=repr(result))
        errors+=result['status']!='ok'
        (out/f'job_{returned:02d}.json').write_text(json.dumps(result))
        returned+=1
        print(json.dumps(dict(returned=returned,status=result['status'],spec=result.get('spec'))),flush=True)
    (out/'completion.json').write_text(json.dumps(dict(returned=returned,errors=errors,finished_unix=time.time())))
    if errors:
        raise RuntimeError('Failures retained')
