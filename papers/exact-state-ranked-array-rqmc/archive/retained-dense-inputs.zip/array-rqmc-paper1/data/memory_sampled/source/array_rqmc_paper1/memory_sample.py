"""Sample a fresh child's RSS after warmup. No claimed OS high-water mark."""
import json
from pathlib import Path
import subprocess
import sys
import time


def rss(pid):
    try:
        lines = Path(f'/proc/{pid}/status').read_text().splitlines()
        return next(int(s.split()[1])*1024 for s in lines if s.startswith('VmRSS:'))
    except (FileNotFoundError,ProcessLookupError,StopIteration):
        return None


def child(request):
    import gc
    from executor import warmup, trajectory
    warmup()
    gc.collect()
    print(json.dumps(dict(ready=True,rss=rss('self'))),flush=True)
    if sys.stdin.readline().strip()!='GO':
        raise RuntimeError('missing measurement handshake')
    result=trajectory(request['spec'],request['seed'],request['method'],audit=False,diagnostics=False)
    print(json.dumps({k:result[k] for k in ['value','alternate_value','seconds','table_bytes']}),flush=True)


def parent(request):
    proc=subprocess.Popen([sys.executable,__file__,'child',json.dumps(request)],
                          stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    ready=json.loads(proc.stdout.readline())
    assert ready['ready'] and ready['rss']>0
    start=time.perf_counter()
    samples=[[0.0,ready['rss']]]
    proc.stdin.write('GO\n')
    proc.stdin.flush()
    while proc.poll() is None:
        value=rss(proc.pid)
        if value is not None:
            samples.append([time.perf_counter()-start,value])
        time.sleep(.002)
    output=proc.stdout.read()
    error=proc.stderr.read()
    if proc.returncode:
        raise RuntimeError(error)
    result=json.loads(output)
    return dict(request=request,ready=ready,samples=samples,result=result,
                sampled_peak_bytes=max(x[1] for x in samples),
                observed_seconds=time.perf_counter()-start,
                maximum_sampling_gap=max(b[0]-a[0] for a,b in zip(samples,samples[1:])),
                interpretation='Sampled peak lower-bounds the continuous-time RSS peak.')


if __name__=='__main__':
    if sys.argv[1]=='child':
        child(json.loads(sys.argv[2]))
    else:
        print(json.dumps(parent(json.loads(sys.argv[1]))))
