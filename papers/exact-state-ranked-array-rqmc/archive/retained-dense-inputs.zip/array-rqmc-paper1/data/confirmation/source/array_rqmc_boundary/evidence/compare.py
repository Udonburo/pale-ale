"""Successor benchmarks: unchanged old order maintenance and strong integer sort.

Run with the generalization study's pinned Python environment. All shared
randomization is real SciPy LMS+shift; no independent rank-block randomization.
"""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT / 'array_rqmc_population'),
               str(ROOT / 'array_rqmc_generalization')]
from benchmarks import model_table, scipy_rank_map, affine_symbols, _reverse
from generalized import advance_adaptive, reference_order
from population import branch_counts, push_counts
import argparse
from collections import Counter
from fractions import Fraction
import json
import platform
import random
import time
import numpy as np
import scipy
from scipy.stats import qmc
from numba import njit


MODELS = [dict(name='queue16', model='queue', capacity=16, symbols=[0, 0, 1, 2], initial=0),
          dict(name='queue64', model='queue', capacity=64, symbols=[0, 0, 0, 1, 1, 1, 2, 3], initial=0),
          dict(name='inventory32', model='inventory', capacity=32, symbols=[0, 1, 2, 4],
               reorder_below=10, initial=32)]


def monotone_parts(table):
    """Exact finite-table certificate: each part is nondecreasing in old state."""
    parts = np.empty_like(table)
    n = 0
    for z in range(table.shape[1]):
        for x in range(len(table)):
            if x and table[x, z] < table[x-1, z]:
                n += 1
            parts[x, z] = n
        n += 1
    return parts, n


@njit(cache=True)
def labelled_update(x, order, z, table, parts):
    branch = np.empty(len(x), dtype=np.int64)
    for r in range(len(order)):
        label = order[r]
        old = x[label]
        branch[r] = parts[old, z[r]]
        x[label] = table[old, z[r]]
    return branch


@njit(cache=True)
def counting_update(xs, z, table):
    counts = np.zeros(len(table), dtype=np.int64)
    for r in range(len(xs)):
        counts[table[xs[r], z[r]]] += 1
    nxt = np.empty_like(xs)
    pos = 0
    for x in range(len(counts)):
        end = pos + counts[x]
        nxt[pos:end] = x
        pos = end
    return nxt, counts


def sparse_hist(counts):
    return tuple((int(x), int(counts[x])) for x in np.flatnonzero(counts))


def baseline_trajectory(spec, seed, method, audit=True):
    started = time.perf_counter()
    table, score, scale = model_table(spec)
    m, T = spec['m'], spec['horizon']
    N, B = 1 << m, table.shape[1]
    d = B.bit_length()-1
    rng = random.Random(seed)
    reverse = np.array([_reverse(z, d) for z in range(B)], dtype=np.int64)
    hist = ((spec['initial'], N),)
    xs = None if method == 'compressed' else np.full(N, spec['initial'], dtype=np.int64)
    if method == 'finite_b_order':
        order = np.arange(N, dtype=np.int64)
        alive = np.ones(N, dtype=np.bool_)
        parts, nb = monotone_parts(table)
    else:
        nb = B
    histories = []
    audits = 0.0
    residual = 0
    for _ in range(T):
        engine = qmc.Sobol(d=2, scramble=True, bits=30, seed=rng.randrange(2**32))
        if method == 'full_points':
            points = engine.random_base2(m)
            z = reverse[np.floor(points[np.argsort(points[:, 0]), 1]*B).astype(np.int64)]
        else:
            cols, b = scipy_rank_map(engine, m, d)
            if method != 'compressed':
                z = affine_symbols(np.array(cols, dtype=np.int64), b, m)
        if method == 'compressed':
            states, counts = zip(*hist)
            flow, nr = branch_counts(counts, cols, b, d)
            residual += nr
            hist = push_counts(states, flow, lambda x, z: int(table[x, z]))
        elif method == 'finite_b_order':
            branch = labelled_update(xs, order, z, table, parts)
            order, active, _, _ = advance_adaptive(order, N, branch, xs, alive, nb)
            if active != N:
                raise AssertionError('unexpected absorption')
        elif method == 'counting_explicit':
            xs, counts = counting_update(xs, z, table)
        else:
            xs = table[xs, z]
            xs.sort()
        if audit:
            a = time.perf_counter()
            if method != 'compressed':
                hist = sparse_hist(np.bincount(xs, minlength=len(table)))
            histories.append(hist)
            audits += time.perf_counter()-a
    numerator = (sum(n*int(score[x]) for x, n in hist) if xs is None
                 else int(score[xs].sum()))
    elapsed = time.perf_counter()-started-audits
    return dict(seconds=elapsed, value=str(Fraction(numerator, N*scale)),
                histories=histories, residual_slots=residual, monotone_parts=nb)


def tandem_table(T):
    # Key = total*(total+1)/2 + queue2: exact paper-described lexicographic sort.
    size = (T+1)*(T+2)//2
    table = np.empty((size, 3), dtype=np.int64)
    total = np.empty(size, dtype=np.int64)
    exceed = np.empty(size, dtype=np.int64)
    for s in range(T+1):
        for q2 in range(s+1):
            q1 = s-q2
            x = s*(s+1)//2+q2
            table[x, 0] = x+1 if q1 else x
            table[x, 1] = (s-1)*s//2+q2-1 if q2 else x
            # This last row is never used for an arrival before the horizon.
            table[x, 2] = (s+1)*(s+2)//2+q2 if s < T else x
            total[x] = s
            exceed[x] = int(q2 > 4)
    return table, total, exceed


def solve_rank(cols, target):
    """Unique preimage of the full consumed coordinate, or None.

    Each consumed Sobol coordinate is injective on the first 2^m points.
    Reject a deficient map rather than silently ignore endpoint multiplicities.
    """
    basis = {}
    m = len(cols)
    for j, col in enumerate(cols):
        value, mask = int(col), 1 << (m-1-j)
        while value:
            p = value.bit_length()-1
            if p in basis:
                a, w = basis[p]
                value ^= a
                mask ^= w
            else:
                basis[p] = (value, mask)
                break
        if not value:
            raise ValueError('endpoint solver requires injective coordinate')
    r = 0
    while target:
        p = target.bit_length()-1
        if p not in basis:
            return None
        a, w = basis[p]
        target ^= a
        r ^= w
    return r


def tandem_map(engine, m):
    full, b = scipy_rank_map(engine, m, 30)
    corrections = []
    # Full output is packed little-endian, with first digit in bit zero.
    for word, before, after in [(7 << 26, 1, 0), (12 << 26, 2, 1)]:
        r = solve_rank(full, _reverse(word, 30) ^ b)
        if r is not None:
            corrections.append((r, before, after))
    return tuple(c & 15 for c in full), b & 15, corrections


def tandem_trajectory(spec, seed, method, audit=True):
    started = time.perf_counter()
    m, T = spec['m'], spec['horizon']
    N = 1 << m
    table, total, exceed = tandem_table(T)
    event = np.array([0 if _reverse(z, 4) < 7 else 1 if _reverse(z, 4) < 12 else 2
                      for z in range(16)], dtype=np.int64)
    rng = random.Random(seed)
    hist = ((0, N),)
    xs = None if method == 'compressed' else np.zeros(N, dtype=np.int64)
    histories, sums, rare = [], 0, 0
    audits, residual, endpoint_hits, max_states = 0.0, 0, 0, 1
    for _ in range(T):
        engine = qmc.Sobol(d=2, scramble=True, bits=30, seed=rng.randrange(2**32))
        if method == 'full_points':
            points = engine.random_base2(m)
            u = points[np.argsort(points[:, 0]), 1]
            z = np.where(u <= 7/16, 0, np.where(u <= 3/4, 1, 2))
            xs, counts = counting_update(xs, z, table)
            sums += int(counts @ total)
            rare += int(counts @ exceed)
        else:
            cols, b, corrections = tandem_map(engine, m)
            endpoint_hits += len(corrections)
            if method == 'counting_explicit':
                z = event[affine_symbols(np.array(cols, dtype=np.int64), b, m)]
                for r, before, after in corrections:
                    if z[r] != before:
                        raise AssertionError('wrong endpoint base symbol')
                    z[r] = after
                xs, counts = counting_update(xs, z, table)
                sums += int(counts @ total)
                rare += int(counts @ exceed)
            elif method == 'compressed':
                states, ns = zip(*hist)
                flow, slots = branch_counts(ns, cols, b, 4)
                residual += slots
                out = Counter(dict(push_counts(states, flow, lambda x, z: int(table[x, event[z]]))))
                for r, before, after in corrections:
                    stop = 0
                    for x, n in hist:
                        stop += n
                        if r < stop:
                            out[int(table[x, before])] -= 1
                            out[int(table[x, after])] += 1
                            break
                hist = tuple(sorted((x, n) for x, n in out.items() if n))
                sums += sum(n*int(total[x]) for x, n in hist)
                rare += sum(n*int(exceed[x]) for x, n in hist)
            else:
                raise ValueError(method)
        if audit:
            a = time.perf_counter()
            if xs is not None:
                hist = sparse_hist(counts)
            histories.append(hist)
            max_states = max(max_states, len(hist))
            audits += time.perf_counter()-a
    elapsed = time.perf_counter()-started-audits
    return dict(seconds=elapsed, value=str(Fraction(sums, T*N)),
                rare_value=str(Fraction(rare, T*N)), histories=histories,
                residual_slots=residual, max_states=max_states, endpoint_hits=endpoint_hits)


def tandem_dp(T, finite_word=False):
    start = time.perf_counter()
    table, total, exceed = tandem_table(T)
    prob = (np.array([7*2**26+1, 5*2**26, 4*2**26-1], dtype=float)/2**30
            if finite_word else np.array([7, 5, 4], dtype=float)/16)
    p = np.zeros(len(table)); p[0] = 1
    length, rare = 0.0, 0.0
    for t in range(T):
        reachable = (t+1)*(t+2)//2
        p = np.bincount(table[:reachable].ravel(),
                        weights=(p[:reachable, None]*prob).ravel(), minlength=len(table))
        length += float(p @ total)
        rare += float(p @ exceed)
    return dict(seconds=time.perf_counter()-start, mean=length/T, rare=rare/T,
                probability_sum=float(p.sum()), finite_word=finite_word)


def warmup():
    affine_symbols(np.array([1, 2], dtype=np.int64), 0, 2)
    spec = dict(MODELS[0], m=4, horizon=2)
    for method in ('finite_b_order', 'counting_explicit'):
        baseline_trajectory(spec, 881, method)
    tandem_trajectory(dict(m=4, horizon=2), 882, 'counting_explicit')


def run(suite, output):
    if output.exists():
        raise FileExistsError('Use a fresh output directory; previous observations are preserved')
    output.mkdir(parents=True)
    warmup()
    if suite == 'baseline':
        specs = [dict(model, m=m, horizon=16, repetitions=5, seed=630011+1000*i+100*m)
                 for i, model in enumerate(MODELS) for m in (10, 20)]
        methods = ['full_points', 'affine_sort', 'finite_b_order', 'counting_explicit', 'compressed']
        runner = baseline_trajectory
    else:
        specs = [dict(name='lecuyer2008_tandem', m=m, horizon=200, repetitions=3,
                      seed=730011+100*m) for m in (12, 16, 20)]
        methods = ['full_points', 'counting_explicit', 'compressed']
        runner = tandem_trajectory
    meta = dict(suite=suite, specs=specs, methods=methods, python=sys.version,
                numpy=np.__version__, scipy=scipy.__version__, platform=platform.platform(),
                processor=platform.processor(), timing='setup and readout included; JIT and audit excluded')
    (output/'manifest.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    rows, checks = [], 0
    for spec in specs:
        for rep in range(spec['repetitions']):
            seed = spec['seed']+rep
            order = methods.copy(); random.Random(seed ^ 9313).shuffle(order)
            reference = None
            for method in order:
                result = runner(spec, seed, method)
                if reference is None:
                    reference = result['histories']
                else:
                    if result['histories'] != reference:
                        raise AssertionError((spec, rep, method, 'histogram mismatch'))
                    checks += spec['horizon']
                row = dict(model=spec['name'], m=spec['m'], T=spec['horizon'], rep=rep,
                           seed=seed, method=method, **{k:v for k,v in result.items() if k != 'histories'})
                rows.append(row)
                with (output/'rows.jsonl').open('a', encoding='utf-8') as f:
                    f.write(json.dumps(row)+'\n')
                # Keep actual integer population histories, not just pass/fail.
                if method == 'compressed':
                    (output/f"history_{spec['name']}_{spec['m']}_{rep}.json").write_text(
                        json.dumps(result['histories']), encoding='utf-8')
                print(json.dumps(row), flush=True)
    dps = [tandem_dp(200, flag) for flag in (False, True)] if suite == 'tandem' else []
    (output/'completion.json').write_text(json.dumps(dict(rows=len(rows),
        matched_step_histograms=checks, dp=dps), indent=2), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('suite', choices=['baseline', 'tandem'])
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    run(args.suite, args.out)
