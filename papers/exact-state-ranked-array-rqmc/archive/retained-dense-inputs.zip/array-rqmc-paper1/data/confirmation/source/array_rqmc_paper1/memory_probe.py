"""Fresh Linux process: one warmup, one production trajectory, OS RSS report."""
import gc
import json
from pathlib import Path
import resource
import sys
from executor import trajectory, warmup


def status():
    fields = {}
    for line in Path('/proc/self/status').read_text().splitlines():
        key, _, value = line.partition(':')
        if key in ('VmRSS','VmHWM'):
            fields[key] = int(value.strip().split()[0]) * 1024
    return fields


def main():
    request = json.loads(sys.argv[1])
    warmup()
    gc.collect()
    before = status()
    reset = False
    reset_error = None
    try:
        Path('/proc/self/clear_refs').write_text('5')
        reset = True
    except OSError as err:
        reset_error = str(err)
    reset_state = status()
    result = trajectory(request['spec'], request['seed'], request['method'],
                        audit=False, diagnostics=False)
    after = status()
    print(json.dumps(dict(request=request, before=before, after_reset=reset_state,
                          after=after, hwm_reset=reset, reset_error=reset_error,
                          rusage_maxrss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                          value=result['value'], alternate_value=result['alternate_value'],
                          seconds=result['seconds'], table_bytes=result['table_bytes'])))


if __name__=='__main__':
    main()
