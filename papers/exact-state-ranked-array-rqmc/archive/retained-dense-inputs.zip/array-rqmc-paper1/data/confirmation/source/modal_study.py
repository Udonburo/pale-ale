"""Private bounded Paper I completion study. Explicit module upload only."""
from pathlib import Path
import json
import shutil
import time
import modal

HERE = Path(__file__).resolve().parent
LOCAL = HERE.parent
FILES = ['array_rqmc_paper1/executor.py', 'array_rqmc_paper1/memory_probe.py',
         'array_rqmc_boundary/evidence/compare.py', 'array_rqmc_population/benchmarks.py',
         'array_rqmc_population/population.py', 'array_rqmc_generalization/generalized.py']
app = modal.App('array-rqmc-paper1-completion')
image = (modal.Image.debian_slim(python_version='3.11')
         .pip_install('numpy==1.26.4', 'scipy==1.15.3', 'numba==0.61.2')
         .env({'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}))
for name in FILES:
    image = image.add_local_file(LOCAL/name, '/root/local/'+name)


@app.function(image=image, cpu=(1.0,1.0), memory=(2048,2048), timeout=1500,
              startup_timeout=180, retries=0, max_containers=4, min_containers=0,
              buffer_containers=0, scaledown_window=2, serialized=True, include_source=False)
def measure(spec):
    import sys
    import platform
    import random
    import subprocess
    import gzip
    import base64
    sys.path.insert(0, '/root/local/array_rqmc_paper1')
    import executor as e
    begin = time.perf_counter()
    cpu = next((s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines()
                if s.startswith('model name')), 'unknown')
    if spec['kind']=='memory':
        rows = []
        for rep in range(3):
            request = dict(spec=dict(name='tandem',m=spec['m'],horizon=200),
                           method=spec['method'],seed=5100000+10000*spec['m']+rep)
            proc = subprocess.run([sys.executable,'/root/local/array_rqmc_paper1/memory_probe.py',
                                   json.dumps(request)],capture_output=True,text=True,timeout=440)
            if proc.returncode:
                return dict(status='failed', spec=spec, returncode=proc.returncode,
                            stdout=proc.stdout, stderr=proc.stderr, memory_rows=rows)
            rows.append(json.loads(proc.stdout))
        return dict(status='ok',spec=spec,memory_rows=rows,cpu=cpu,
                    wall_seconds=time.perf_counter()-begin,platform=platform.platform())
    e.warmup()
    rows, checks, retained = [], 0, None
    for rep in range(spec['repetitions']):
        seed = spec['seed']+rep
        order = list(e.METHODS)
        random.Random(seed ^ 912663).shuffle(order)
        ref = None
        for method in order:
            result = e.trajectory(spec,seed,method)
            if ref is None:
                ref = result
            elif (result['histories']!=ref['histories'] or result['traces']!=ref['traces'] or
                  result['value']!=ref['value'] or result['alternate_value']!=ref['alternate_value']):
                return dict(status='mismatch',spec=spec,rep=rep,method=method,
                            reference=ref,counterexample=result,rows=rows)
            else:
                checks += spec['horizon']
            rows.append(dict(method=method,rep=rep,seed=seed,
                             **{k:v for k,v in result.items() if k!='histories'}))
        if rep==0:
            retained = base64.b64encode(gzip.compress(json.dumps(ref['histories'],
                       separators=(',',':')).encode(),mtime=0)).decode()
    return dict(status='ok',spec=spec,rows=rows,matched_step_histograms=checks,
                representative_histograms_gzip_base64=retained,cpu=cpu,
                python=sys.version,platform=platform.platform(),wall_seconds=time.perf_counter()-begin)


@app.local_entrypoint()
def main():
    from executor import specs
    conditions = specs()
    conditions += [dict(kind='memory',m=m,method=method) for m in (12,16,20)
                   for method in ('counting','prefix','boundary')]
    out = HERE/'data'/'confirmation'
    if out.exists():
        raise FileExistsError('Prior observations are preserved; choose a distinct successor.')
    out.mkdir(parents=True)
    for name in FILES:
        dest=out/'source'/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(LOCAL/name,dest)
    shutil.copyfile(__file__,out/'source'/'modal_study.py')
    shutil.copyfile(HERE/'PROTOCOL.md',out/'source'/'PROTOCOL.md')
    manifest = dict(conditions=conditions,count=len(conditions),cpu=1,memory_mib=2048,
                    timeout=1500,retries=0,max_containers=4,started_unix=time.time(),
                    base_execution_envelope_usd=len(conditions)*1500*(0.0000131+2*0.00000222),
                    accounting='Excludes image/startup/idle; not invoice or billing cap.')
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('START',len(conditions),'bounded CPU jobs',flush=True)
    returned=errors=0
    for result in measure.map(conditions,order_outputs=False,return_exceptions=True):
        if isinstance(result,BaseException):
            result=dict(status='infrastructure_error',error=repr(result))
        errors+=result['status']!='ok'
        (out/f'job_{returned:02d}.json').write_text(json.dumps(result),encoding='utf-8')
        returned+=1
        print(json.dumps(dict(returned=returned,status=result['status'],spec=result.get('spec'),
                              wall_seconds=result.get('wall_seconds'))),flush=True)
    (out/'completion.json').write_text(json.dumps(dict(returned=returned,errors=errors,
                                     finished_unix=time.time())),encoding='utf-8')
    if errors:
        raise RuntimeError(f'{errors} failures retained; no outcome-dependent retries')
