"""Successor kernels; no dependency on or mutation of the published companion.

GF(2) words store mathematical coordinate j at bit j (zero based). Numeric
rank reverses those bits so the first sorting digit is most significant.
Consumed d-vectors use bit i for output row i; branch labels use that packing.
"""
import os
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
import numpy as np
from numba import njit


def reverse_bits(word, m):
    result = 0
    for _ in range(m):
        result = (result << 1) | (word & 1)
        word >>= 1
    return result


def apply(rows, vector):
    return sum(((int(row) & int(vector)).bit_count() & 1) << i
               for i, row in enumerate(rows))


def row_times(row, matrix):
    out = 0
    for i, value in enumerate(matrix):
        if (int(row) >> i) & 1:
            out ^= int(value)
    return out


def multiply(left, right):
    return tuple(row_times(row, right) for row in left)


def inverse(rows):
    m = len(rows)
    a = [int(row) | (1 << (m+i)) for i, row in enumerate(rows)]
    for j in range(m):
        pivot = next((i for i in range(j, m) if (a[i] >> j) & 1), None)
        if pivot is None:
            raise ValueError('Singular sorting prefix')
        a[j], a[pivot] = a[pivot], a[j]
        for i in range(m):
            if i != j and (a[i] >> j) & 1:
                a[i] ^= a[j]
    return tuple(row >> m for row in a)


def unit_lower(m, code):
    rows = []
    for i in range(m):
        rows.append((1 << i) | (code & ((1 << i)-1)))
        code >>= i
    return tuple(rows)


def basis(words):
    pivots = {}
    for word in words:
        x = int(word)
        while x:
            bit = x.bit_length()-1
            if bit in pivots:
                x ^= pivots[bit]
            else:
                pivots[bit] = x
                break
    return tuple(pivots[k] for k in sorted(pivots))


def span(words):
    values = {0}
    for word in basis(words):
        values |= {x ^ word for x in tuple(values)}
    return values


def columns(rows, m):
    return tuple(sum(((int(row) >> j) & 1) << i
                     for i, row in enumerate(rows)) for j in range(m))


def rows_from_columns(cols, d):
    return tuple(sum(((int(col) >> i) & 1) << j
                     for j, col in enumerate(cols)) for i in range(d))


class CosetSampler:
    def __init__(self, g, m):
        self.m, self.d = m, len(g)
        self.cols = columns(g, m)
        self.bases = [basis(self.cols[j+1:]) for j in range(m)]
        self.coefficient_bits = sum(map(len, self.bases))
        self.entropy_bits = self.d + self.coefficient_bits

    def sample(self, rng):
        cols = []
        for g, v in zip(self.cols, self.bases):
            word = int(rng.integers(1 << len(v)))
            c = g
            for i, element in enumerate(v):
                if (word >> i) & 1:
                    c ^= element
            cols.append(c)
        return tuple(cols), int(rng.integers(1 << self.d))


@njit(cache=True)
def affine_symbols(cols, offset, m):
    """O(2**m) packed-word Gray traversal, scattered into numeric rank."""
    n = 1 << m
    output = np.empty(n, dtype=np.int64)
    value, rank = offset, 0
    output[0] = value
    for i in range(1, n):
        # Coordinate words are little-first; rank digit weights are reversed.
        low = i & -i
        j = 0
        while (1 << j) != low:
            j += 1
        value ^= cols[j]
        rank ^= 1 << (m-1-j)
        output[rank] = value
    return output


def point_sort_reference(a, h, s, t):
    m = len(a)
    pairs = [(reverse_bits(apply(a, q) ^ s, m), apply(h, q) ^ t)
             for q in range(1 << m)]
    pairs.sort(key=lambda pair: pair[0])
    if any(pairs[i][0] != i for i in range(len(pairs))):
        raise ValueError('Nonunique sorting prefixes')
    return np.array([z for _, z in pairs], dtype=np.int64)


@njit(cache=True)
def scalar_orbit_counts(m, start, stop):
    n = 1 << m
    counts = np.zeros((n, n), dtype=np.int64)
    rows = np.empty(m, dtype=np.int64)
    images = np.zeros(n, dtype=np.int64)
    low_index = np.zeros(n, dtype=np.int64)
    for i in range(m):
        low_index[1 << i] = i
    for code in range(start, stop):
        tail = code
        for i in range(m):
            rows[i] = (1 << i) | (tail & ((1 << i)-1))
            tail >>= i
        for h in range(1, n):
            low = h & -h
            images[h] = images[h ^ low] ^ rows[low_index[low]]
            counts[h, images[h]] += 1
    return counts


@njit(cache=True, inline='always')
def before(left, right, x):
    return x[left] < x[right] or (x[left] == x[right] and left < right)


@njit(cache=True)
def advance(previous, active_count, symbols, x, alive, branch_count, repair=1):
    """repair=1 linear label scatter; =2 comparison sort; =0 negative control.

    x/alive already contain the updated active states. previous is the correct
    pre-update order. Fixed dense label universe; symbols are indexed by rank.
    No NaN, no reactivation, no change to old dead states. Branches evaluated
    on each pre-update subsequence must be nondecreasing. Output newly allocated.
    """
    n = len(previous)
    if active_count == 0:
        return previous.astype(np.int64), 0, 0, 0
    counts = np.zeros(branch_count, dtype=np.int64)
    for r in range(active_count):
        counts[symbols[r]] += 1
    offsets = np.zeros(branch_count+1, dtype=np.int64)
    for b in range(branch_count):
        offsets[b+1] = offsets[b] + counts[b]
    cursor = offsets[:-1].copy()
    runs = np.empty(active_count, dtype=np.int64)
    for r in range(active_count):
        b = symbols[r]
        runs[cursor[b]] = previous[r]
        cursor[b] += 1
    group_of = np.full(n, -1, dtype=np.int64)
    group_cursor = np.empty(active_count, dtype=np.int64)
    groups, tied = 0, 0
    for b in range(branch_count):
        start = offsets[b]
        while start < offsets[b+1]:
            end = start + 1
            inverted = False
            while end < offsets[b+1] and x[runs[end]] == x[runs[start]]:
                if runs[end] < runs[end-1]:
                    inverted = True
                end += 1
            if inverted:
                group_cursor[groups] = start
                if repair == 1:
                    for j in range(start, end):
                        group_of[runs[j]] = groups
                elif repair == 2:
                    runs[start:end] = np.sort(runs[start:end])
                groups += 1
                tied += end-start
            start = end
    if repair == 1 and groups:
        for label in range(n):
            group = group_of[label]
            if group >= 0:
                runs[group_cursor[group]] = label
                group_cursor[group] += 1
    cursor = offsets[:-1].copy()
    heap = np.empty(branch_count, dtype=np.int64)
    heap_size = 0
    for b in range(branch_count):
        if counts[b]:
            pos = heap_size
            heap_size += 1
            while pos:
                parent = (pos-1)//2
                if before(runs[cursor[b]], runs[cursor[heap[parent]]], x):
                    heap[pos] = heap[parent]
                    pos = parent
                else:
                    break
            heap[pos] = b
    output = np.empty(n, dtype=np.int64)
    dead = np.empty(active_count, dtype=np.int64)
    survivors, nd = 0, 0
    while heap_size:
        b = heap[0]
        label = runs[cursor[b]]
        if alive[label]:
            output[survivors] = label
            survivors += 1
        else:
            dead[nd] = label
            nd += 1
        cursor[b] += 1
        if cursor[b] == offsets[b+1]:
            heap_size -= 1
            if not heap_size:
                break
            b = heap[heap_size]
        pos = 0
        while 2*pos+1 < heap_size:
            child = 2*pos+1
            if child+1 < heap_size and before(runs[cursor[heap[child+1]]], runs[cursor[heap[child]]], x):
                child += 1
            if before(runs[cursor[heap[child]]], runs[cursor[b]], x):
                heap[pos] = heap[child]
                pos = child
            else:
                break
        heap[pos] = b
    i, j, out = 0, active_count, survivors
    while i < nd or j < n:
        if j == n or (i < nd and before(dead[i], previous[j], x)):
            output[out] = dead[i]
            i += 1
        else:
            output[out] = previous[j]
            j += 1
        out += 1
    return output, survivors, groups, tied


def reference_order(x, alive):
    return np.lexsort((np.arange(len(x)), x, ~alive)).astype(np.int64)


@njit(cache=True)
def advance_adaptive(previous, active_count, symbols, x, alive, branch_count):
    """Successor fast path: prove the updated full key already ordered in O(N)."""
    for i in range(1, len(previous)):
        left, right = previous[i-1], previous[i]
        if alive[left] != alive[right]:
            ordered = alive[left] and not alive[right]
        else:
            ordered = before(left, right, x)
        if not ordered:
            return advance(previous, active_count, symbols, x, alive, branch_count, 1)
    return previous.astype(np.int64), int(np.sum(alive)), 0, 0


def update(x, alive, order, symbols, slopes, shifts, kinds, barrier):
    """Identical declared evaluation schedule for both ordering implementations."""
    for b in range(len(slopes)):
        labels = order[:int(alive.sum())][symbols[:int(alive.sum())] == b]
        # alive is not changed until all branches have been evaluated.
        values = x[labels] * slopes[b]
        values = values + shifts[b]
        if kinds[b] == 1:
            values = np.clip(values, -2.0, 2.0)
        elif kinds[b] == 2:
            values = np.floor(values * 4.0) / 4.0
        elif kinds[b] == 3:
            values = np.tanh(values)
        x[labels] = values
    alive &= np.abs(x) < barrier

