"""Finite population execution, boundary covariance, and standard flow rounding.

Rank bits are MSB first; columns are packed little-endian output vectors.
Pure Python integer operations are the reference arithmetic. No source from
the author's supplied prototype is used (only the mathematical notes).
"""
from bisect import bisect_right
from collections import Counter, defaultdict, deque
from fractions import Fraction
from functools import lru_cache
from itertools import product
from math import lcm
import random
import numpy as np


def parity(a):
    return int(a).bit_count() & 1


def span(words):
    out = {0}
    for w in words:
        out |= {v ^ int(w) for v in tuple(out)}
    return tuple(sorted(out))


def symbol(cols, r, offset=0):
    value = int(offset)
    for j, c in enumerate(reversed(cols)):
        if (r >> j) & 1:
            value ^= int(c)
    return value


def triangular_columns(g, code):
    """G U, with all strict-lower entries of U enumerated by code."""
    cols = list(g)
    bit = 0
    for j in range(len(g)):
        for i in range(j + 1, len(g)):
            if (code >> bit) & 1:
                cols[j] ^= g[i]
            bit += 1
    return tuple(cols)


def sample_columns(g, d, rng):
    # Independent column cosets. This has the reference law, not its seed map.
    cols = tuple(c ^ rng.choice(span(g[j + 1:])) for j, c in enumerate(g))
    return cols, rng.randrange(1 << d)


def prefix_counts(cols, offset, d, stop):
    """Exact rank-prefix counts; works with dependent/zero output rows."""
    m, B = len(cols), 1 << d
    if not 0 <= stop <= 1 << m:
        raise ValueError('prefix outside rank range')
    if stop == 1 << m:
        image = span(cols)
        out = [0] * B
        for z in image:
            out[z ^ offset] = (1 << m) // len(image)
        return out
    out, fixed = [0] * B, offset
    for j, c in enumerate(cols):
        free = m - j - 1
        if (stop >> free) & 1:
            image = span(cols[j + 1:])
            multiplicity = (1 << free) // len(image)
            for z in image:
                out[z ^ fixed] += multiplicity
            fixed ^= c
    return out


def branch_counts(counts, cols, offset, d, boundary=True):
    """One common affine rank map for every run; never independent run draws."""
    m, B = len(cols), 1 << d
    if sum(counts) != 1 << m or any(n <= 0 for n in counts):
        raise ValueError('invalid positive run counts')
    balanced = m >= d and len(span(cols[-d:])) == B
    out, a, residual = [], 0, 0
    for n in counts:
        end = a + n
        if boundary and balanced:
            lo, hi = ((a + B - 1) // B) * B, (end // B) * B
            if lo <= hi:
                c = [(hi - lo) // B] * B
                slots = list(range(a, lo)) + list(range(hi, end))
            else:
                c, slots = [0] * B, range(a, end)
            for r in slots:
                c[symbol(cols, r, offset)] += 1
                residual += 1
        else:
            before, after = prefix_counts(cols, offset, d, a), prefix_counts(cols, offset, d, end)
            c = [v - u for u, v in zip(before, after)]
        assert sum(c) == n
        out.append(c)
        a = end
    if boundary and balanced:
        assert residual <= B * max(0, len(counts) - 1)
    return out, residual


def cyclic_counts(counts, B, shift):
    out, start = [], 0
    for n in counts:
        base, extra = divmod(n, B)
        c = [base] * B
        for k in range(extra):
            c[(start + shift + k) % B] += 1
        out.append(c)
        start += n
    return out


def push_counts(states, flows, transition):
    out = Counter()
    for x, row in zip(states, flows):
        for z, n in enumerate(row):
            if n:
                out[transition(x, z)] += int(n)
    return tuple(sorted(out.items()))


def explicit_push(states, counts, cols, offset, transition):
    out, r = Counter(), 0
    for x, n in zip(states, counts):
        for _ in range(n):
            out[transition(x, symbol(cols, r, offset))] += 1
            r += 1
    return tuple(sorted(out.items()))


def walsh(table, exact=True):
    a = np.array(table, dtype=object if exact else float, copy=True)
    if a.ndim == 2:
        a = a[:, :, None]
    B = a.shape[1]
    if B & (B - 1):
        raise ValueError('symbol alphabet must be a power of two')
    h = 1
    while h < B:
        for j in range(0, B, 2 * h):
            lo, hi = a[:, j:j+h].copy(), a[:, j+h:j+2*h].copy()
            a[:, j:j+h], a[:, j+h:j+2*h] = lo + hi, lo - hi
        h *= 2
    return a  # Unnormalized: covariance denominator is (N B)^2.


def energies(counts, table, levels=None, exact=True):
    N = sum(counts)
    m = N.bit_length() - 1
    if N != 1 << m:
        raise ValueError('population size must be a power of two')
    w = walsh(table, exact)
    S, B, q = w.shape
    ends = [0]
    for n in counts:
        ends.append(ends[-1] + n)
    prefix = np.zeros((S + 1, B, q), dtype=object if exact else float)
    for j, n in enumerate(counts):
        prefix[j + 1] = prefix[j] + n * w[j]
    E = np.zeros((B, m + 1, q, q), dtype=object if exact else float)

    def integral(a, alpha):
        if a == N:
            return prefix[-1, alpha]
        j = bisect_right(ends, a) - 1
        return prefix[j, alpha] + (a - ends[j]) * w[j, alpha]

    for alpha in range(1, B):
        E[alpha, 0] = np.outer(prefix[-1, alpha], prefix[-1, alpha])
        for k in (range(1, m + 1) if levels is None else levels):
            L = 1 << (m - k)
            parents = {a // (2 * L) for a in ends[1:-1] if a % (2 * L)}
            for p in parents:
                a = 2 * L * p
                diff = 2 * integral(a + L, alpha) - integral(a, alpha) - integral(a + 2 * L, alpha)
                E[alpha, k] += np.outer(diff, diff)
    return E


def covariance_from_energy(E, g, N, exact=True):
    B, _, q, _ = E.shape
    total = np.zeros((q, q), dtype=object if exact else float)
    for alpha in range(1, B):
        k = max((j + 1 for j, c in enumerate(g) if parity(alpha & c)), default=0)
        total += E[alpha, k]
    if exact:
        return [[Fraction(total[i, j], (N * B) ** 2) for j in range(q)] for i in range(q)]
    return np.asarray(total, dtype=float) / (N * B) ** 2


@lru_cache(None)
def hyperplanes(A):
    if len(A) <= 1:
        return ()
    ambient = max(A).bit_length()
    candidates = {tuple(a for a in A if not parity(a & v)) for v in range(1, 1 << ambient)}
    return tuple(sorted(V for V in candidates if len(V) * 2 == len(A)))


def separating_vector(A, V, d):
    return next(v for v in range(1, 1 << d)
                if all(not parity(a & v) for a in V) and any(parity(a & v) for a in A))


@lru_cache(None)
def complete_flags(d):
    @lru_cache(None)
    def rec(A):
        if len(A) == 1:
            return ((),)
        out = []
        for V in hyperplanes(A):
            v = separating_vector(A, V, d)
            out.extend(cols + (v,) for cols in rec(V))
        return tuple(out)
    return rec(tuple(range(1 << d)))


def weighted_flag_dp(E, Q):
    B, width, q, _ = E.shape
    d, m = B.bit_length() - 1, width - 1
    if m < d:
        raise ValueError('complete suffix flag requires m >= d')

    @lru_cache(None)
    def rec(A):
        if len(A) == 1:
            return 0, ()
        k = m - d + len(A).bit_length() - 1
        best = None
        for V in hyperplanes(A):
            val, cols = rec(V)
            missing = set(A) - set(V)
            val += sum(Q[i][j] * E[a, k, j, i] for a in missing for i in range(q) for j in range(q))
            candidate = val, cols + (separating_vector(A, V, d),)
            if best is None or candidate < best:
                best = candidate
        return best
    value, suffix = rec(tuple(range(B)))
    return value, (0,) * (m - d) + suffix


def exact_readout_law(counts, table, g, d):
    """Independent pointwise reference, intentionally does not call counts/oracle."""
    N, m = sum(counts), len(g)
    rows = [row for row, n in zip(table, counts) for _ in range(n)]
    vector = isinstance(rows[0][0], (list, tuple, np.ndarray))
    q = len(rows[0][0]) if vector else 1
    law = Counter()
    for code in range(1 << (m * (m - 1) // 2)):
        cols = triangular_columns(g, code)
        for offset in range(1 << d):
            value = [Fraction(0)] * q
            for r, row in enumerate(rows):
                f = row[symbol(cols, r, offset)]
                for k in range(q):
                    value[k] += Fraction(f[k] if vector else f, N)
            law[tuple(value)] += 1
    total = sum(law.values())
    return {y: Fraction(n, total) for y, n in law.items()}


def law_moments(law):
    q = len(next(iter(law)))
    mean = [sum(p * y[i] for y, p in law.items()) for i in range(q)]
    cov = [[sum(p * (y[i] - mean[i]) * (y[j] - mean[j]) for y, p in law.items()) for j in range(q)] for i in range(q)]
    return mean, cov


def fractional_cycle(edges, values, denominator):
    """Find an undirected cycle, including parallel-edge cycles."""
    forest = defaultdict(list)
    for edge_id, (u, v) in enumerate(edges):
        if values[edge_id] % denominator == 0:
            continue
        queue, parent = deque([v]), {v: None}
        while queue and u not in parent:
            node = queue.popleft()
            for other, eid in forest[node]:
                if other not in parent:
                    parent[other] = (node, eid)
                    queue.append(other)
        if u in parent:
            # New chord u -> v, followed by the forest path v -> u.
            cycle = [(edge_id, 1)]
            node = u
            while parent[node] is not None:
                prev, eid = parent[node]
                cycle.append((eid, 1 if edges[eid] == (prev, node) else -1))
                node = prev
            return cycle
        forest[u].append((v, edge_id))
        forest[v].append((u, edge_id))
    if any(v % denominator for v in values):
        raise AssertionError('fractional forest with integer node divergences')
    return None


def flow_setup(counts, destinations, probabilities=None):
    S, B = len(counts), len(destinations[0])
    if probabilities is None:
        probabilities = [[Fraction(1, B)] * B for _ in counts]
    probabilities = [[Fraction(p) for p in row] for row in probabilities]
    assert all(sum(row) == 1 for row in probabilities)
    denominator = lcm(*(p.denominator for row in probabilities for p in row))
    ys = sorted({y for row in destinations for y in row})
    index = {y: S + k for k, y in enumerate(ys)}
    sink = S + len(ys)
    edges, values, expected = [], [], Counter()
    for j, (n, row) in enumerate(zip(counts, probabilities)):
        for z, p in enumerate(row):
            val = int(n * p * denominator)
            edges.append((j, index[destinations[j][z]]))
            values.append(val)
            expected[destinations[j][z]] += val
    for y in ys:
        edges.append((index[y], sink))
        values.append(expected[y])
    return tuple(edges), tuple(values), denominator, ys


def rounding_children(edges, values, denominator):
    cycle = fractional_cycle(edges, values, denominator)
    if cycle is None:
        return None
    plus = min(denominator - values[e] % denominator if s == 1 else values[e] % denominator for e, s in cycle)
    minus = min(values[e] % denominator if s == 1 else denominator - values[e] % denominator for e, s in cycle)
    a, b = list(values), list(values)
    for e, s in cycle:
        a[e] += s * plus
        b[e] -= s * minus
    return tuple(a), tuple(b), minus, plus


def round_flow(counts, destinations, rng, probabilities=None):
    edges, values, den, ys = flow_setup(counts, destinations, probabilities)
    steps = 0
    while True:
        child = rounding_children(edges, values, den)
        if child is None:
            break
        a, b, wa, wb = child
        values = a if rng.randrange(wa + wb) < wa else b
        steps += 1
    S, B = len(counts), len(destinations[0])
    flows = [[values[j * B + z] // den for z in range(B)] for j in range(S)]
    hist = tuple((y, values[S * B + k] // den) for k, y in enumerate(ys) if values[S * B + k])
    assert all(sum(row) == n for row, n in zip(flows, counts))
    assert sum(n for y, n in hist) == sum(counts)
    return flows, hist, steps


def exact_flow_law(counts, destinations, probabilities=None, atom_limit=100000):
    edges, initial, den, ys = flow_setup(counts, destinations, probabilities)
    law = defaultdict(Fraction)
    stack = [(initial, Fraction(1))]
    visited = 0
    while stack:
        values, probability = stack.pop()
        child = rounding_children(edges, values, den)
        if child is None:
            law[tuple(v // den for v in values)] += probability
        else:
            a, b, wa, wb = child
            stack.append((a, probability * Fraction(wa, wa + wb)))
            stack.append((b, probability * Fraction(wb, wa + wb)))
        visited += 1
        if visited > atom_limit:
            raise RuntimeError('exact flow tree size limit reached')
    return dict(law), initial, den, ys
