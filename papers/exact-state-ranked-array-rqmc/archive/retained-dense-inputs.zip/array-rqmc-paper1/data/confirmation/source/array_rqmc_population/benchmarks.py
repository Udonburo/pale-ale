"""Costed finite-model comparisons. Models and settings are declared in specs.

Law-preserving explicit/compressed pairs are distinct from coupling designs.
DP and conditional averaging may return scalar answers outside the N-grid.
"""
from collections import Counter
from fractions import Fraction as F
import json
import random
import time
import numpy as np
from numba import njit
from population import (span, parity, symbol, sample_columns, branch_counts,
    cyclic_counts, push_counts, round_flow, energies, covariance_from_energy,
    weighted_flag_dp, complete_flags)


@njit(cache=True)
def affine_symbols(cols, offset, m):
    N = 1 << m
    out = np.empty(N, dtype=np.int64)
    value, rank = offset, 0
    out[0] = value
    for i in range(1, N):
        low, j = i & -i, 0
        while (1 << j) != low:
            j += 1
        value ^= cols[j]
        rank ^= 1 << (m-1-j)
        out[rank] = value
    return out


def model_table(spec):
    K, arrivals = spec['capacity'], tuple(spec['symbols'])
    B = len(arrivals)
    xs = np.arange(K+1, dtype=np.int64)
    table = np.empty((K+1, B), dtype=np.int64)
    if spec['model'] == 'queue':
        for z,a in enumerate(arrivals):
            table[:,z] = np.minimum(K, np.maximum(0,xs-1)+a)
        score = xs**2
    elif spec['model'] == 'inventory':
        level = spec.get('reorder_below', max(1,K//3))
        for z,demand in enumerate(arrivals):
            table[:,z] = np.maximum(0, np.where(xs<level,K,xs)-demand)
        score = (K-xs)**2
    else:
        raise ValueError(spec['model'])
    return table, score, K*K


def exact_dp(table, initial, T, score, scale):
    K, B = table.shape
    paths = [0]*K
    paths[initial] = 1
    for t in range(T):
        nxt = [0]*K
        for x,n in enumerate(paths):
            if n:
                for z in range(B):
                    nxt[int(table[x,z])] += n
        paths = nxt
    return F(sum(n*int(f) for n,f in zip(paths,score)), B**T*scale), paths


def float_dp(table, initial, T, payoff):
    p = np.zeros(len(table)); p[initial] = 1
    for t in range(T):
        p = np.bincount(table.ravel(), weights=np.repeat(p/table.shape[1], table.shape[1]), minlength=len(table))
    return float(p@payoff), p


def _rank_inverse(rows):
    m = len(rows)
    a = [int(row) | (1 << (m+i)) for i,row in enumerate(rows)]
    for j in range(m):
        pivot = next(i for i in range(j,m) if (a[i]>>j)&1)
        a[j],a[pivot] = a[pivot],a[j]
        for i in range(m):
            if i != j and ((a[i]>>j)&1):
                a[i] ^= a[j]
    return tuple(row>>m for row in a)


def _reverse(x,width):
    result=0
    for _ in range(width):
        result=(result<<1)|(x&1); x>>=1
    return result


def scipy_rank_map(engine,m,d):
    bits=30
    A=tuple(sum(((int(engine._sv[0,j])>>(bits-1-i))&1)<<j for j in range(m)) for i in range(m))
    H=tuple(sum(((int(engine._sv[1,j])>>(bits-1-i))&1)<<j for j in range(m)) for i in range(d))
    inv=_rank_inverse(A)
    coeff=[]
    for row in H:
        c=0
        for j,a in enumerate(inv):
            if (row>>j)&1: c ^= a
        coeff.append(c)
    s=_reverse(int(engine._shift[0])>>(bits-m),m)
    t=_reverse(int(engine._shift[1])>>(bits-d),d)
    b=t ^ sum(parity(c&s)<<i for i,c in enumerate(coeff))
    cols=tuple(sum(((c>>j)&1)<<i for i,c in enumerate(coeff)) for j in range(m))
    return cols,b


def sobol_trajectory(spec,seed,method):
    from scipy.stats import qmc
    started=time.perf_counter()
    table,score,scale=model_table(spec)
    B=table.shape[1]; d=B.bit_length()-1; m=spec['m']; N=1<<m
    rng=random.Random(seed)
    hist=((spec['initial'],N),)
    xs=np.full(N,spec['initial'],dtype=np.int64) if method!='sobol_compressed' else None
    checkpoints=[]; residual=0; audit_seconds=0.0
    reverse=np.array([_reverse(z,d) for z in range(B)],dtype=np.int64)
    for t in range(spec['horizon']):
        engine=qmc.Sobol(d=2,scramble=True,bits=30,seed=rng.randrange(2**32))
        if method=='sobol_points':
            points=engine.random_base2(m)
            z=reverse[np.floor(points[np.argsort(points[:,0]),1]*B).astype(np.int64)]
            xs=table[xs,z]; xs.sort()
            audit_start=time.perf_counter()
            unique,n=np.unique(xs,return_counts=True)
            hist=tuple((int(x),int(c)) for x,c in zip(unique,n))
            audit_seconds+=time.perf_counter()-audit_start
        elif method=='sobol_affine_explicit':
            cols,b=scipy_rank_map(engine,m,d)
            z=affine_symbols(np.array(cols,dtype=np.int64),b,m)
            xs=table[xs,z]; xs.sort()
            audit_start=time.perf_counter()
            unique,n=np.unique(xs,return_counts=True)
            hist=tuple((int(x),int(c)) for x,c in zip(unique,n))
            audit_seconds+=time.perf_counter()-audit_start
        else:
            cols,b=scipy_rank_map(engine,m,d)
            states,counts=zip(*hist)
            flow,nslots=branch_counts(counts,cols,b,d)
            hist=push_counts(states,flow,lambda x,z:int(table[x,z]))
            residual+=nslots
        # A per-step hashable mathematical histogram is returned for equality,
        # not a tolerance comparison of the floating terminal readout.
        checkpoints.append(hist)
    numerator=(int(score[xs].sum()) if xs is not None else sum(n*int(score[x]) for x,n in hist))
    value=F(numerator,N*scale)
    elapsed=time.perf_counter()-started-audit_seconds
    return dict(seconds=elapsed,value=str(value),histories=checkpoints,residual_slots=residual)


def sobol_job(spec):
    # Warm the compiled generator outside all paired timing rows.
    affine_symbols(np.array([1,2],dtype=np.int64),0,2)
    methods=['sobol_points','sobol_affine_explicit','sobol_compressed']
    rows=[]; checks=0
    for rep in range(spec['repetitions']):
        seed=spec['seed']+rep
        order=methods.copy(); random.Random(seed^9313).shuffle(order)
        reference=None
        for method in order:
            result=sobol_trajectory(spec,seed,method)
            if reference is None: reference=result['histories']
            else:
                assert result['histories']==reference,(spec,rep,method)
                checks+=spec['horizon']
            rows.append(dict(rep=rep,seed=seed,method=method,seconds=result['seconds'],
                             value=result['value'],residual_slots=result['residual_slots']))
    return dict(rows=rows,pathwise_histogram_checks=checks,contract='same realized SciPy rank input and next histograms')


def adaptive_flag(counts,states,table,payoff,m,d,mode,remaining=None,feature_payoff=None):
    B=1<<d
    if mode=='minimax_approx':
        features=feature_payoff[table[np.array(states,dtype=int)]]
        E=energies(counts,features,levels=range(m-d+1,m+1),exact=False)
        flags=[(0,)*(m-d)+g for g in complete_flags(d)]
        C=np.array([covariance_from_energy(E,g,1<<m,False) for g in flags])
        # Best-response averaging is a candidate generator, not a certificate.
        weights=np.zeros(len(flags)); current=np.zeros((3,3))
        for i in range(24):
            _,vecs=np.linalg.eigh(current)
            a=vecs[:,-1]
            k=int(np.argmin(np.einsum('i,kij,j->k',a,C,a)))
            weights[k]+=1
            current+=(C[k]-current)/(i+1)
        return flags,weights/weights.sum()
    values=payoff if mode=='greedy' else remaining
    feature=values[table[np.array(states,dtype=int)]]
    E=energies(counts,feature,levels=range(m-d+1,m+1),exact=False)
    _,g=weighted_flag_dp(E,[[1.0]])
    return [g],np.array([1.0])


def population_trajectory(spec,seed,method):
    started=time.perf_counter()
    table,score,scale=model_table(spec)
    payoff=score.astype(float)/scale
    B=table.shape[1]; d=B.bit_length()-1; m=spec['m']; N=1<<m; T=spec['horizon']
    rbstarted=time.perf_counter()
    one=payoff[table].mean(axis=1)
    rb1setup=time.perf_counter()-rbstarted
    two=one[table].mean(axis=1)
    rbsetup=time.perf_counter()-rbstarted
    future=None
    if method=='continuation':
        future=[None]*(T+1); future[T]=payoff
        for t in reversed(range(T)): future[t]=future[t+1][table].mean(axis=1)
    K=spec['capacity']; grid=np.arange(K+1)/K
    feature_payoff=np.stack([grid,grid**2,(grid==0).astype(float)],axis=1)
    g=(0,)*(m-d)+tuple(1<<j for j in range(d))
    hist=((spec['initial'],N),)
    rng=random.Random(seed)
    xs=np.full(N,spec['initial'],dtype=np.int64) if method=='fixed_explicit' else None
    max_support=1; residual=cycles=0
    checkpoint_values={}; checkpoint_times={}
    audit_seconds=rb_eval_seconds=0.0
    for t in range(T+1):
        if t==T-2:
            before=time.perf_counter()
            checkpoint_values['rb2']=(float(two[xs].mean()) if xs is not None else sum(n*two[x] for x,n in hist)/N)
            eval_seconds=time.perf_counter()-before
            checkpoint_times['rb2']=before-started-audit_seconds-rbsetup-rb_eval_seconds+rbsetup+eval_seconds
            rb_eval_seconds+=eval_seconds
        if t==T-1:
            before=time.perf_counter()
            checkpoint_values['rb1']=(float(one[xs].mean()) if xs is not None else sum(n*one[x] for x,n in hist)/N)
            eval_seconds=time.perf_counter()-before
            checkpoint_times['rb1']=before-started-audit_seconds-rbsetup-rb_eval_seconds+rb1setup+eval_seconds
            rb_eval_seconds+=eval_seconds
        if t==T: break
        states,counts=zip(*hist)
        if method=='cyclic':
            flow=cyclic_counts(counts,B,rng.randrange(B))
            hist=push_counts(states,flow,lambda x,z:int(table[x,z]))
        elif method=='flow':
            dest=table[np.array(states,dtype=int)].tolist()
            _,hist,ncycles=round_flow(counts,dest,rng)
            cycles+=ncycles
        else:
            if method in ('greedy','continuation','minimax_approx'):
                choices,weights=adaptive_flag(counts,states,table,payoff,m,d,method,
                                               None if future is None else future[t+1],feature_payoff)
                if len(choices)==1: g=choices[0]
                else:
                    pick=rng.random(); total=0
                    for candidate,w in zip(choices,weights):
                        total+=w
                        if pick<total:
                            g=candidate; break
            cols,b=sample_columns(g,d,rng)
            if method=='fixed_explicit':
                symbols=affine_symbols(np.array(cols,dtype=np.int64),b,m)
                xs=table[xs,symbols]; xs.sort()
                audit_start=time.perf_counter()
                unique,n=np.unique(xs,return_counts=True)
                hist=tuple((int(x),int(c)) for x,c in zip(unique,n))
                audit_seconds+=time.perf_counter()-audit_start
            else:
                flow,nslots=branch_counts(counts,cols,b,d)
                residual+=nslots
                hist=push_counts(states,flow,lambda x,z:int(table[x,z]))
        max_support=max(max_support,len(hist))
        assert sum(n for x,n in hist)==N
    numerator=(int(score[xs].sum()) if xs is not None else sum(n*int(score[x]) for x,n in hist))
    raw=F(numerator,N*scale)
    elapsed=time.perf_counter()-started-audit_seconds-rbsetup-rb_eval_seconds
    return dict(raw=str(raw),rb1=checkpoint_values['rb1'],rb2=checkpoint_values['rb2'],
                seconds=elapsed,rb1_seconds=checkpoint_times['rb1'],rb2_seconds=checkpoint_times['rb2'],
                rb_setup_seconds=rbsetup,max_support=max_support,residual_slots=residual,
                flow_cycles=cycles,final_histogram=hist)


def benchmark_job(spec):
    affine_symbols(np.array([1,2],dtype=np.int64),0,2)
    table,score,scale=model_table(spec)
    begin=time.perf_counter()
    exact,paths=exact_dp(table,spec['initial'],spec['horizon'],score,scale)
    exact_seconds=time.perf_counter()-begin
    begin=time.perf_counter()
    dp,p=float_dp(table,spec['initial'],spec['horizon'],score/scale)
    dp_seconds=time.perf_counter()-begin
    assert abs(dp-float(exact))<2e-13
    methods=spec['methods']; rows=[]
    for rep in range(spec['repetitions']):
        seed=spec['seed']+rep
        order=methods.copy(); random.Random(seed^67412).shuffle(order)
        common=None
        for method in order:
            result=population_trajectory(spec,seed,method)
            if method in ('fixed','fixed_explicit'):
                if common is None: common=result['final_histogram']
                else: assert common==result['final_histogram']
            # Retain every terminal outcome, including unfavorable runs.
            result.pop('final_histogram')
            rows.append(dict(method=method,rep=rep,seed=seed,**result))
    return dict(exact_mean=str(exact),exact_dp_seconds=exact_seconds,float_dp_mean=dp,
                float_dp_seconds=dp_seconds,rows=rows,readout='normalized square',
                note='One-dimensional finite-model benchmark; exact DP is an admissible competitor.')


def scaling_job(spec):
    table,score,scale=model_table(spec)
    m,T=spec['m'],spec['horizon']; B=table.shape[1]; d=B.bit_length()-1; N=1<<m
    g=(0,)*(m-d)+tuple(1<<j for j in range(d))
    rows=[]
    for rep in range(spec['repetitions']):
        rng=random.Random(spec['seed']+rep)
        hist=((spec['initial'],N),); paths=[0]*len(table); paths[spec['initial']]=1
        first_difference=None; max_support=1; residual=0; seconds=0
        for t in range(1,T+1):
            started=time.perf_counter()
            states,counts=zip(*hist)
            cols,b=sample_columns(g,d,rng)
            flow,nslots=branch_counts(counts,cols,b,d)
            hist=push_counts(states,flow,lambda x,z:int(table[x,z]))
            seconds+=time.perf_counter()-started
            residual+=nslots; max_support=max(max_support,len(hist))
            nxt=[0]*len(table)
            for x,n in enumerate(paths):
                if n:
                    for z in range(B): nxt[int(table[x,z])]+=n
            paths=nxt
            h=dict(hist)
            if first_difference is None and any(h.get(x,0)*B**t != N*n for x,n in enumerate(paths)):
                first_difference=t
        signed_num=sum(n*int(score[x]) for x,n in hist)*B**T-N*sum(n*int(f) for n,f in zip(paths,score))
        error=F(signed_num,N*scale*B**T)
        rows.append(dict(rep=rep,seconds=seconds,first_DP_difference=first_difference,
                         exact_terminal_error=str(error),max_support=max_support,residual_slots=residual))
    return dict(N=N,m=m,B=B,horizon=T,sufficient_saturation_condition=m>=d*T,rows=rows,
                timing_scope='compressed update including coefficient draw; DP reference excluded')


def envelope_job(spec):
    # All states are covered. The observed trajectory is never the domain.
    table,score,scale=model_table(spec)
    K,B=len(table),table.shape[1]; T=spec['horizon']; f=[F(int(x),scale) for x in score]
    P=np.zeros((K,K),dtype=np.int64)
    for x in range(K):
        for z in range(B): P[x,table[x,z]]+=1
    beta=F(int(max(np.abs(P[x]-P[y]).sum() for x in range(K) for y in range(K))),2*B)
    def advance(values):
        return [sum(values[int(y)] for y in row)/B for row in table]
    def halfosc(values):
        return (max(values)-min(values))/2
    true=[None]*(T+1); true[T]=f
    for t in reversed(range(T)): true[t]=advance(true[t+1])
    # Deliberately cheap, deterministic horizon-truncated surrogate.
    approx=[]
    for t in range(T+1):
        value=f.copy()
        for _ in range(min(spec['lookahead'],T-t)): value=advance(value)
        approx.append(value)
    bounds=[F(0)]*(T+1); actual=[halfosc([a-b for a,b in zip(true[t],approx[t])]) for t in range(T+1)]
    residuals=[]
    for t in reversed(range(T)):
        following=advance(approx[t+1])
        delta=halfosc([a-b for a,b in zip(approx[t],following)])
        bounds[t]=delta+beta*bounds[t+1]
        residuals.append(delta)
        assert actual[t]<=bounds[t]
    return dict(beta=str(beta),oscillation_error=list(map(str,actual)),bounds=list(map(str,bounds)),
                max_bound=float(max(bounds)),initial_actual=float(actual[0]),initial_bound=float(bounds[0]),
                domain_states=K,lookahead=spec['lookahead'],note='Exact rational audit on the entire finite state domain.')


def dp_cost_job(spec):
    # Successor timing: the initial performance phase timed the DP recurrence
    # after constructing the shared table. This includes that setup explicitly.
    rows=[]
    for rep in range(spec['repetitions']):
        order=['exact','float']; random.Random(spec['seed']+rep).shuffle(order)
        answers={}
        for method in order:
            start=time.perf_counter()
            table,score,scale=model_table(spec)
            if method=='exact':
                answer,_=exact_dp(table,spec['initial'],spec['horizon'],score,scale)
            else:
                answer,_=float_dp(table,spec['initial'],spec['horizon'],score/scale)
            seconds=time.perf_counter()-start
            answers[method]=answer
            rows.append(dict(rep=rep,method=method,seconds=seconds,value=str(answer)))
        assert abs(float(answers['exact'])-answers['float'])<2e-13
    return dict(rows=rows,timing_scope='model table + DP + terminal readout; independent repeated baseline')


def run_benchmark_job(spec):
    return {'benchmark':benchmark_job,'sobol':sobol_job,'scaling':scaling_job,
            'envelope':envelope_job,'dp_cost':dp_cost_job}[spec['kind']](spec)
