"""Paper I ablation: shared realized maps, exact counts, unchanged old updates."""
from pathlib import Path
import sys
LOCAL = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(LOCAL/'array_rqmc_boundary'/'evidence'))
import compare as old
from population import span, branch_counts, push_counts, prefix_counts, symbol
import numpy as np
from scipy.stats import qmc
from fractions import Fraction
from collections import Counter
from bisect import bisect_right
import random
import time

METHODS = ('counting', 'prefix', 'boundary')


class CachedPrefix:
    """Cache suffix images once per map; endpoints are evaluated once per run.

    Equal successive images share their tuple; arbitrary deficient maps work.
    All integer counts are exact Python integers.
    """
    def __init__(self, columns, offset, d):
        self.cols, self.b, self.B = tuple(columns), offset, 1 << d
        self.m = len(self.cols)
        self.images = [None] * (self.m + 1)
        self.images[self.m] = (0,)
        for j in range(self.m - 1, -1, -1):
            later = self.images[j + 1]
            self.images[j] = (later if self.cols[j] in later else
                              tuple(sorted(later + tuple(x ^ self.cols[j] for x in later))))
        self.queries = self.additions = 0

    def prefix(self, stop):
        if not 0 <= stop <= 1 << self.m:
            raise ValueError('rank prefix outside population')
        out = [0] * self.B
        self.queries += 1
        if stop == 1 << self.m:
            image = self.images[0]
            multiplicity = (1 << self.m) // len(image)
            for value in image:
                out[value ^ self.b] = multiplicity
            self.additions += len(image)
            return out
        fixed = self.b
        for j, col in enumerate(self.cols):
            free = self.m - j - 1
            if (stop >> free) & 1:
                image = self.images[j + 1]
                multiplicity = (1 << free) // len(image)
                for value in image:
                    out[value ^ fixed] += multiplicity
                self.additions += len(image)
                fixed ^= col
        return out

    def flows(self, counts):
        out, before, end = [], [0] * self.B, 0
        for n in counts:
            if n <= 0:
                raise ValueError('counts must be positive')
            end += n
            after = self.prefix(end)
            row = [a-b for a, b in zip(after, before)]
            assert sum(row) == n and min(row) >= 0
            out.append(row)
            before = after
        if end != 1 << self.m:
            raise ValueError('counts must sum to N')
        return out


def mixed_count(counts, B):
    end, ids = 0, set()
    for n in counts[:-1]:
        end += n
        if end % B:
            ids.add(end // B)
    return len(ids)


def trajectory(spec, seed, method, audit=True, diagnostics=True):
    if method not in METHODS:
        raise ValueError(method)
    start = time.perf_counter()
    phases = dict(setup=0.0, input=0.0, counts=0.0, update=0.0, readout=0.0)
    tandem = spec['name'] == 'tandem'
    m, T = spec['m'], spec['horizon']
    N = 1 << m
    if tandem:
        table, score, alternate = old.tandem_table(T)
        d, scale, initial = 4, T, 0
        event = np.array([0 if old._reverse(z, 4) < 7 else
                          1 if old._reverse(z, 4) < 12 else 2 for z in range(16)], dtype=np.int64)
    else:
        table, score, scale = old.model_table(spec)
        alternate = np.array([int(x == 0) for x in range(len(table))], dtype=np.int64)
        d, initial = (table.shape[1].bit_length() - 1), spec['initial']
    B = 1 << d
    hist = ((initial, N),)
    xs = np.full(N, initial, dtype=np.int64) if method == 'counting' else None
    rng = random.Random(seed)
    primary_sum = alternate_sum = 0
    histories, traces, stats = [], [], []
    audit_seconds = 0.0
    phases['setup'] = time.perf_counter() - start
    for t in range(T):
        if diagnostics:
            a = time.perf_counter()
            sizes = tuple(n for _, n in hist)
            state_count = len(hist)
            mixed = mixed_count(sizes, B)
            audit_seconds += time.perf_counter() - a
        a = time.perf_counter()
        engine = qmc.Sobol(d=2, scramble=True, bits=30, seed=rng.randrange(2**32))
        if tandem:
            cols, offset, corrections = old.tandem_map(engine, m)
        else:
            cols, offset = old.scipy_rank_map(engine, m, d)
            corrections = []
        if method == 'counting':
            zs = old.affine_symbols(np.array(cols, dtype=np.int64), offset, m)
            if tandem:
                zs = event[zs]
                for rank, before, after in corrections:
                    assert zs[rank] == before
                    zs[rank] = after
        phases['input'] += time.perf_counter() - a
        queries = additions = residual = 0
        if method != 'counting':
            a = time.perf_counter()
            states, ns = zip(*hist)
            if method == 'prefix':
                counter = CachedPrefix(cols, offset, d)
                flow = counter.flows(ns)
                queries, additions = counter.queries, counter.additions
            else:
                flow, residual = branch_counts(ns, cols, offset, d)
            phases['counts'] += time.perf_counter() - a
        a = time.perf_counter()
        if method == 'counting':
            xs, counts = old.counting_update(xs, zs, table)
        else:
            out = Counter(dict(push_counts(states, flow, lambda x, z:
                          int(table[x, event[z] if tandem else z]))))
            if corrections:
                ends, stop = [], 0
                for n in ns:
                    stop += n
                    ends.append(stop)
                for rank, before, after in corrections:
                    x = states[bisect_right(ends, rank)]
                    out[int(table[x, before])] -= 1
                    out[int(table[x, after])] += 1
            hist = tuple(sorted((x, n) for x, n in out.items() if n))
        phases['update'] += time.perf_counter() - a
        a = time.perf_counter()
        # Time-average queue readouts are intrinsic. Finite-model readout is terminal.
        if tandem or t == T-1:
            if method == 'counting':
                first = int(counts @ score)
                second = int(counts @ alternate)
            else:
                first = sum(n * int(score[x]) for x, n in hist)
                second = sum(n * int(alternate[x]) for x, n in hist)
            primary_sum += first
            alternate_sum += second
        phases['readout'] += time.perf_counter() - a
        if audit or diagnostics:
            a = time.perf_counter()
            if method == 'counting':
                hist = old.sparse_hist(counts)
            if audit:
                histories.append(hist)
                # All per-time sums permit downstream finite-path readouts.
                traces.append((sum(n * int(score[x]) for x, n in hist),
                               sum(n * int(alternate[x]) for x, n in hist)))
            if diagnostics:
                stats.append(dict(S=state_count, S_next=len(hist), mixed=mixed,
                                  prefix_queries=queries, prefix_additions=additions,
                                  residual_slots=residual, endpoint_hits=len(corrections)))
            audit_seconds += time.perf_counter() - a
    elapsed = time.perf_counter() - start - audit_seconds
    return dict(seconds=elapsed, phases=phases, histories=histories, traces=traces,
                diagnostics=stats, value=str(Fraction(primary_sum, N*scale)),
                alternate_value=str(Fraction(alternate_sum, N*(T if tandem else 1))),
                numerator=primary_sum, alternate_numerator=alternate_sum,
                denominator=N*scale, table_bytes=table.nbytes+score.nbytes+alternate.nbytes)


def warmup():
    old.affine_symbols(np.array([1, 2], dtype=np.int64), 0, 2)
    old.counting_update(np.zeros(4, dtype=np.int64), np.zeros(4, dtype=np.int64),
                        np.zeros((2, 2), dtype=np.int64))
    # No target-size or target-horizon run occurs during warmup.


def specs():
    cells = [dict(name=model['name'], **{k:v for k,v in model.items() if k != 'name'},
                  m=m, horizon=16, repetitions=5, seed=2100000+10000*i+100*m,
                  kind='finite', batch=0)
             for i, model in enumerate(old.MODELS) for m in (10,20)]
    cells += [dict(name='tandem', m=m, horizon=200, repetitions=16,
                   seed=3100000+10000*m+16*batch, kind='tandem', batch=batch)
              for m in (12,16,20) for batch in range(8)]
    return cells
