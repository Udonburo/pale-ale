"""Recompute saved exact finite-word and ideal means from the prior DP source."""
import importlib.util
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('reference_analysis',ROOT/'supporting/reference_analysis.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
saved=json.loads((ROOT/'supporting/summary.json').read_text())['exact_tandem']
for word in (False,True):
    actual=module.exact_tandem(200,word)
    expected=next(r for r in saved if r['finite_word']==word)
    assert all(actual[k]==expected[k] for k in ('mean','rare','states'))
print('PASS: both exact rational means for both kernels')
