"""Rebuild timing summaries and independently check complete saved run records."""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import csv
import json
import statistics as st
import time

HERE = Path(__file__).resolve().parent


def exact_tandem(T, finite_word=False):
    # Independent queue-pair recurrence, not the packed-key transition table.
    D = 2**30 if finite_word else 16
    weights = (7*2**26+1, 5*2**26, 4*2**26-1) if finite_word else (7,5,4)
    dist = {(0,0): 1}
    length, rare, denominator = 0, 0, 1
    start = time.perf_counter()
    for t in range(T):
        nxt = defaultdict(int)
        for (a,b), n in dist.items():
            nxt[(a-1,b+1) if a else (a,b)] += n*weights[0]
            nxt[(a,b-1) if b else (a,b)] += n*weights[1]
            nxt[(a+1,b)] += n*weights[2]
        dist = nxt
        denominator *= D
        assert sum(dist.values()) == denominator
        length = D*length + sum(n*(a+b) for (a,b),n in dist.items())
        rare = D*rare + sum(n for (a,b),n in dist.items() if b>4)
    mean, exceed = Fraction(length,T*denominator), Fraction(rare,T*denominator)
    return dict(mean=str(mean), rare=str(exceed), mean_float=float(mean),
                rare_float=float(exceed), states=len(dist), seconds=time.perf_counter()-start,
                finite_word=finite_word)


def main():
    rows = []
    matched = {}
    jobs = []
    for suite in ('baseline','tandem'):
        root = HERE/'data'/suite
        completion = json.loads((root/'completion.json').read_text())
        local = [json.loads(s) for s in (root/'rows.jsonl').read_text().splitlines()]
        assert len(local) == completion['rows']
        rows += [dict(platform='local', suite=suite, **r) for r in local]
        matched['local_'+suite] = completion['matched_step_histograms']
    root = HERE/'data'/'cloud'
    done = json.loads((root/'completion.json').read_text())
    assert done['returned'] == 9 and done['errors'] == 0
    for f in sorted(root.glob('job_*.json')):
        job = json.loads(f.read_text())
        assert job['status'] == 'ok'
        jobs.append(job)
        rows += [dict(platform='cloud', suite=job['spec']['suite'], **r) for r in job['rows']]
        matched['cloud_'+f.stem] = job['matched_step_histograms']
        for history in job['histories'].values():
            assert len(history) == job['spec']['horizon']
            for hist in history:
                assert sum(n for _,n in hist) == 1 << job['spec']['m']
                assert all(n > 0 for _,n in hist)
                assert [x for x,_ in hist] == sorted(set(x for x,_ in hist))
    comparisons = defaultdict(list)
    paired = defaultdict(list)
    for r in rows:
        comparisons[(r['platform'],r['suite'],r['model'],r['m'],r['method'])].append(r['seconds'])
        paired[(r['platform'],r['model'],r['m'],r['rep'])].append(r)
    for rs in paired.values():
        assert len({r['value'] for r in rs}) == 1
        if 'rare_value' in rs[0]:
            assert len({r['rare_value'] for r in rs}) == 1
    aggregates = []
    for key, values in sorted(comparisons.items()):
        platform,suite,model,m,method = key
        aggregates.append(dict(platform=platform,suite=suite,model=model,m=m,method=method,
            n=len(values), median_seconds=st.median(values), min_seconds=min(values),max_seconds=max(values)))
    ratios = []
    for platform,suite,model,m in sorted(set(k[:4] for k in comparisons)):
        ps = []
        for key, rs in paired.items():
            if key[:3] == (platform,model,m):
                d = {r['method']:r['seconds'] for r in rs}
                ps.append(d['counting_explicit']/d['compressed'])
        ratios.append(dict(platform=platform,suite=suite,model=model,m=m,
                           median=st.median(ps),min=min(ps),max=max(ps)))
    exact = [exact_tandem(200, flag) for flag in (False, True)]
    for job in jobs:
        for dp in job['dp']:
            truth = exact[int(dp['finite_word'])]
            assert abs(dp['mean']-truth['mean_float']) < 1e-12
            assert abs(dp['rare']-truth['rare_float']) < 1e-12
    total_wall = sum(j['wall_seconds'] for j in jobs)
    result = dict(rows=len(rows), aggregates=aggregates, paired_counting_over_compressed=ratios,
                  matched_step_histograms=sum(matched.values()), matched_by_run=matched,
                  exact_tandem=exact, cloud_function_wall_seconds=total_wall,
                  base_resource_estimate_usd=total_wall*(0.0000131+2*0.00000222),
                  cpu_names=sorted(set(j['cpu'] for j in jobs)),
                  caveat='Reported resource estimate is not the provider invoice.')
    (HERE/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    with (HERE/'timings.csv').open('w',newline='',encoding='utf-8') as f:
        cols = ['platform','suite','model','m','T','rep','seed','method','seconds','value']
        writer = csv.DictWriter(f,fieldnames=cols,extrasaction='ignore')
        writer.writeheader();writer.writerows(rows)
    print(json.dumps(dict(rows=len(rows), matched_step_histograms=result['matched_step_histograms'],
                         cpu_names=result['cpu_names'], exact_means=[x['mean_float'] for x in exact],
                         base_resource_estimate_usd=result['base_resource_estimate_usd'],
                         cloud_ratios=[r for r in ratios if r['platform']=='cloud']),indent=2))


if __name__ == '__main__':
    main()
