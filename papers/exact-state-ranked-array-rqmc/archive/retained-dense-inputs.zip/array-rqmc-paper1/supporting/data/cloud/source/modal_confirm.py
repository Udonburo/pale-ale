"""Bounded CPU confirmation of the evidence benchmark, no repository upload."""
from pathlib import Path
import json
import shutil
import time
import modal

HERE = Path(__file__).resolve().parent
LOCAL = HERE.parents[1]
FILES = ['array_rqmc_boundary/evidence/compare.py',
         'array_rqmc_population/benchmarks.py', 'array_rqmc_population/population.py',
         'array_rqmc_generalization/generalized.py']
app = modal.App('array-rqmc-publication-evidence-oct1')
image = (modal.Image.debian_slim(python_version='3.11')
         .pip_install('numpy==1.26.4', 'scipy==1.15.3', 'numba==0.61.2')
         .env({'OMP_NUM_THREADS':'1', 'OPENBLAS_NUM_THREADS':'1', 'MKL_NUM_THREADS':'1'}))
for name in FILES:
    image = image.add_local_file(LOCAL/name, '/root/local/'+name)


@app.function(image=image, cpu=(1.0, 1.0), memory=(2048, 2048), timeout=900,
              startup_timeout=180, retries=0, max_containers=4,
              min_containers=0, buffer_containers=0, scaledown_window=2,
              serialized=True, include_source=False)
def measure(spec):
    import sys
    sys.path.insert(0, '/root/local/array_rqmc_boundary/evidence')
    import compare as c
    start = c.time.perf_counter()
    c.warmup()
    runner = c.baseline_trajectory if spec['suite'] == 'baseline' else c.tandem_trajectory
    methods = (['full_points', 'affine_sort', 'finite_b_order', 'counting_explicit', 'compressed']
               if spec['suite'] == 'baseline' else ['full_points', 'counting_explicit', 'compressed'])
    rows, histories, checks = [], {}, 0
    for rep in range(spec['repetitions']):
        seed = spec['seed']+rep
        order = methods.copy(); c.random.Random(seed ^ 9313).shuffle(order)
        ref = None
        for method in order:
            result = runner(spec, seed, method)
            if ref is None:
                ref = result['histories']
            else:
                assert result['histories'] == ref, (spec, rep, method)
                checks += spec['horizon']
            rows.append(dict(model=spec['name'], m=spec['m'], T=spec['horizon'],
                rep=rep, seed=seed, method=method,
                **{k:v for k,v in result.items() if k != 'histories'}))
            if method == 'compressed':
                histories[str(rep)] = result['histories']
    dp = ([c.tandem_dp(spec['horizon'], flag) for flag in (False, True)]
          if spec['suite'] == 'tandem' else [])
    cpu = next((s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines()
                if s.startswith('model name')), 'unknown')
    return dict(status='ok', spec=spec, rows=rows, histories=histories,
                matched_step_histograms=checks, dp=dp, cpu=cpu,
                platform=c.platform.platform(), python=sys.version,
                wall_seconds=c.time.perf_counter()-start)


@app.local_entrypoint()
def main():
    # Fresh seeds: local measurements are known development comparisons.
    from compare import MODELS
    specs = [dict(suite='baseline', **model, m=m, horizon=16, repetitions=5,
                  seed=930011+1000*i+100*m)
             for i, model in enumerate(MODELS) for m in (10,20)]
    specs += [dict(suite='tandem', name='lecuyer2008_tandem', m=m, horizon=200,
                   repetitions=3, seed=1030011+100*m) for m in (12,16,20)]
    out = HERE/'data'/'cloud'
    if out.exists():
        raise FileExistsError('Existing observations are preserved')
    out.mkdir(parents=True)
    for name in FILES:
        dest = out/'source'/name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(LOCAL/name, dest)
    shutil.copyfile(__file__, out/'source'/'modal_confirm.py')
    manifest = dict(specs=specs, cpu_limit=1, memory_mib=2048, timeout_seconds=900,
        startup_timeout_seconds=180, retries=0, max_containers=4,
        price_source='https://modal.com/pricing', price_checked='2026-10-01',
        base_execution_envelope_usd=len(specs)*900*(0.0000131+2*0.00000222),
        notes='Base resource envelope excludes build/startup and is not an invoice or account balance.',
        started_unix=time.time())
    (out/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print('START', len(specs), 'bounded CPU tasks', flush=True)
    errors, returned = 0, 0
    for result in measure.map(specs, order_outputs=False, return_exceptions=True):
        if isinstance(result, BaseException):
            result = dict(status='infrastructure_error', error=repr(result))
        errors += result['status'] != 'ok'
        (out/f'job_{returned:02d}.json').write_text(json.dumps(result), encoding='utf-8')
        returned += 1
        print(json.dumps(dict(returned=returned, status=result['status'],
                             spec=result.get('spec'), seconds=result.get('wall_seconds'))), flush=True)
    (out/'completion.json').write_text(json.dumps(dict(returned=returned, errors=errors,
        finished_unix=time.time())), encoding='utf-8')
    if errors:
        raise RuntimeError(f'{errors} tasks failed; failures are retained')
