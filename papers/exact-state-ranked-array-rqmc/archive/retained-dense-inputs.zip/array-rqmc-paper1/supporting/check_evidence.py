"""Independent pointwise checks for new baseline adapter and literature model."""
from compare import *
from population import symbol


def main():
    warmup()
    labelled = 0
    for model in MODELS:
        table, _, _ = model_table(model)
        parts, nb = monotone_parts(table)
        for seed in range(12):
            rng = np.random.default_rng(seed)
            n = 128
            x = rng.integers(0, len(table), n, dtype=np.int64)
            reference = x.copy()
            alive = np.ones(n, dtype=np.bool_)
            order = reference_order(x, alive)
            ref_order = order.copy()
            for t in range(12):
                z = rng.integers(0, table.shape[1], n, dtype=np.int64)
                reference[ref_order] = table[reference[ref_order], z]
                ref_order = reference_order(reference, alive)
                branch = labelled_update(x, order, z, table, parts)
                order, _, _, _ = advance_adaptive(order, n, branch, x, alive, nb)
                assert np.array_equal(x, reference)
                assert np.array_equal(order, ref_order)
                labelled += 1
    baseline_checks = 0
    for model in MODELS:
        for m in (2, 4, 8):
            spec = dict(model, m=m, horizon=12)
            truth = baseline_trajectory(spec, 809+m, 'full_points')
            for method in ('affine_sort', 'finite_b_order', 'counting_explicit', 'compressed'):
                r = baseline_trajectory(spec, 809+m, method)
                assert r['histories'] == truth['histories']
                assert r['value'] == truth['value']
                baseline_checks += 12
    # A separate queue-pair implementation validates every reachable table entry.
    table, total, exceed = tandem_table(12)
    model_checks = 0
    for q1 in range(12):
        for q2 in range(12-q1):
            s = q1+q2; x = s*(s+1)//2+q2
            outputs = [(q1-1, q2+1) if q1 else (q1, q2),
                       (q1, q2-1) if q2 else (q1, q2), (q1+1, q2)]
            for event, (a, b) in enumerate(outputs):
                assert table[x, event] == (a+b)*(a+b+1)//2+b
                model_checks += 1
    # Force both exact finite-word threshold values into real SciPy nets.
    endpoint_checks = 0
    for word in (7 << 26, 12 << 26):
        for m in (2, 4, 8):
            for seed in range(5):
                engine = qmc.Sobol(2, scramble=True, bits=30, seed=seed)
                engine._shift[1] = word
                engine._quasi = engine._shift.copy()
                engine._first_point = engine._shift.reshape(1, 2).astype(float)/2**30
                cols, b, corrections = tandem_map(engine, m)
                assert corrections, 'forced threshold was not found'
                points = engine.random_base2(m)
                u = points[np.argsort(points[:, 0]), 1]
                expected = np.where(u <= 7/16, 0, np.where(u <= 3/4, 1, 2))
                event = [0 if _reverse(z,4)<7 else 1 if _reverse(z,4)<12 else 2 for z in range(16)]
                actual = np.array([event[symbol(cols, r, b)] for r in range(1 << m)])
                for rank, before, after in corrections:
                    assert actual[rank] == before
                    actual[rank] = after
                assert np.array_equal(actual, expected)
                endpoint_checks += 1
    tandem_checks = 0
    for m in (4, 8, 10):
        for seed in range(4):
            spec = dict(m=m, horizon=20)
            truth = tandem_trajectory(spec, seed, 'full_points')
            for method in ('counting_explicit', 'compressed'):
                r = tandem_trajectory(spec, seed, method)
                assert r['histories'] == truth['histories']
                assert r['value'] == truth['value']
                assert r['rare_value'] == truth['rare_value']
                tandem_checks += 20
    # Mean under all 16 equal-probability symbols, independent state-space DP.
    dist = {(0, 0): Fraction(1)}
    avg = Fraction(0)
    for t in range(4):
        nxt = Counter()
        for (a, b), p in dist.items():
            nxt[(a-1,b+1) if a else (a,b)] += p*Fraction(7,16)
            nxt[(a,b-1) if b else (a,b)] += p*Fraction(5,16)
            nxt[(a+1,b)] += p*Fraction(4,16)
        dist = nxt
        avg += sum(p*(a+b) for (a,b),p in dist.items())
    assert abs(tandem_dp(4)['mean']-float(avg/4)) < 1e-14
    result = dict(status='PASS', labelled_updates=labelled,
                  baseline_step_histograms=baseline_checks, model_transitions=model_checks,
                  forced_endpoint_maps=endpoint_checks, tandem_step_histograms=tandem_checks,
                  four_step_exact_mean=str(avg/4))
    Path(__file__).with_name('validation.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    from compare import _reverse
    main()
