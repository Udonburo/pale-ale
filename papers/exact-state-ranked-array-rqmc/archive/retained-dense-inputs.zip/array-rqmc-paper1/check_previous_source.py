"""Run prior input-extraction and endpoint checks against the bundled source."""
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'data/confirmation/source/array_rqmc_boundary/evidence'))
runpy.run_path(str(ROOT/'supporting/check_evidence.py'), run_name='__main__')
