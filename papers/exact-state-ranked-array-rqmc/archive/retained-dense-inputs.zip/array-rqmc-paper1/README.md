# Retained dense-study inputs

Original source and observations supporting Supplement S4. Extract this
directory and run `python analyze.py` to regenerate the error table and
CDF; `python check_reference.py` independently recomputes the exact means.
The analyzer also checks its original timing and sampled-memory inputs;
those historical observations are not pooled with the six-method study.

These files were selected without editing from array-rqmc-paper1-private.zip.
The parent public release records its SHA-256 and each selected file hash.
Python source: MPL-2.0. Author documentation and saved data: CC BY 4.0.
Dependencies retain their own licenses; no runtime library is included.
