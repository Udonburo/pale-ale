Paper source bundle
===================

Included files
- main.tex
- README.txt

Build
- latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

Notes
- This manuscript uses an inline thebibliography environment in main.tex.
- No external .bib files, figure files, local .sty/.cls files, or \\input dependencies are required.
- Build artifacts are intentionally excluded.